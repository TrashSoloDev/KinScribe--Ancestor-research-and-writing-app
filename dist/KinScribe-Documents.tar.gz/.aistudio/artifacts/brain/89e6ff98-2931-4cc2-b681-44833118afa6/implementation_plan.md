# KinScribe: Ancestry Research & Family History Book Studio

An intuitive, senior-friendly genealogy workspace designed specifically for grandfather to seamlessly research his ancestors across FamilySearch and Ancestry.com, view unified deduplicated life timelines with clickable source verification links, and write his family history manuscript in a Google Docs-style document editor without losing his reading or editing position when switching tabs.

## User Review & Critical Decisions

> [!IMPORTANT]
> The core UX choices and historical context have been tailored specifically for grandfather **Ward Scott** (author of *The Fitt's Village Story: From Sugar to Salt* on Amazon):
> 1. **Data Source Integration**: FamilySearch sign-in simulation with real deep-search links into Barbados Church Records (1637–1984) and Civil Vital registers, plus drag-and-drop GEDCOM file import (.ged) and live unified cross-site query assistant for Caribbean & diaspora passenger manifests.
> 2. **Navigation & Layout**: Senior-optimized tab switcher ("My Manuscript Book" vs "Genealogy Research") with persistent scroll and cursor position restoration so grandfather never loses his place.
> 3. **Fact Synthesis**: Chronological life timeline per ancestor featuring automatic deduplication across FamilySearch and Ancestry, high-contrast source badges, direct clickable external verification URLs, and one-click "Cite in Book" actions.
> 4. **Follow-Up Manuscript**: Seeded with *Echoes of Fitts Village: An Ancestral Genealogy*, documenting the Scott, Alleyne, Ward, and Baird lineages as they transitioned from sugar plantation tenancy to independent seafaring along the St. James coast.
> 5. **Companion Book Features (Added)**:
>    - **Fitts Village Coastal Land & Kinship Map**: Interactive visual strip map of Highway 1 (Samuel Scott Freehold Parcel, Ancil Scott Boatyard, St. James Parish Church, Carlton Estate, Barbados Archives) with one-click insertion of geographical notes into chapters.
>    - **Grandpa's Oral History & Voice Dictation**: High-contrast, large-button speech-to-text dictation using Web Speech API with custom prompts (e.g. dawn boat launches, white cedar steam-bending) and one-tap insertion into the active manuscript chapter.
>    - **Amazon KDP 6" × 9" Trade Paperback Exporter**: Generates formatted trade paperback pages with half-title, dedication, auto-calculated table of contents, running headers, and formatted citations ready for Amazon publishing.
>    - **Barbados Parish Archives Presets**: Instant filter pills for St. James (Fitts Village & Holetown), St. Michael (Black Rock Archives), St. Thomas, St. Peter, and Transatlantic Diaspora.
>    - **Archival Photo Scrapbook Gallery**: Curated historical imagery of flying fish sloops, St. James Parish Church, 1898 deeds, and seine-hauls with photo uploads and "Attach to Chapter" formatting.
>    - **Starred Key Discoveries Flagging & Filter**: Individual star button on every timeline fact with visual gold badges, plus a one-click "Starred Only" toggle filter in the research toolbar with persistent browser storage.
>    - **Download as PDF & Publication Preview**: Dedicated 1-click "Download as PDF" button with interactive preview modal (`ChapterPdfExportModal`), paper format options (US Letter, A4, 6"×9" Trade Paperback), line-spacing & text scale controls, and automatic end-of-document Archival Citations compilation.
>    - **Sleek, Modern 2-Tier Toolbar**: Streamlined layout grouping document actions (PDF export, draft upload, researched fact insertion) and rich text formatting controls with intuitive touch targets for effortless authoring.
>    - **Archival Fact-Checker & Google Grounding (`ArchivalChatTab`)**: Purely domain-native archival research station with zero artificial AI identifiers in user-facing UI, clean mode titles (`Fact Grounding`, `Deep Verification`, `Quick Lookup`), strict non-emotional academic directives, no validating of erroneous claims, full book context awareness, and one-click "Insert into Chapter" actions with verified sources.
>    - **Direct Codebase Export to Documents**: Project files compiled and synchronized to `~/Documents/KinScribe` in the local environment, paired with an automated browser download endpoint (`/api/download-project`) and in-app button in the Companion Tools menu to save `KinScribe-Documents.tar.gz` directly into the user's computer Documents folder.

---

### 1. Overview & Core Concept

- **What It Does**: 
  - **Research Tab**: Allows grandfather to connect or simulate sign-in to FamilySearch.org and Ancestry.com, parse his existing family tree files (GEDCOM standard), and search across historical records. An intelligent deduplication engine merges duplicate birth, marriage, census, military, and death records while displaying distinct source attribution badges. Every record provides a direct link out to FamilySearch or Ancestry to verify the original scan or index.
  - **Book Writer Tab (Google Docs Style)**: A distraction-free, paper-styled rich text manuscript editor with an accessible toolbar (headings, font sizing, bold, italic, lists, quotes, alignment, page breaks), chapter outlines, word counting, and footnote citations directly linked to researched records.
  - **Position Memory**: Seamless tab switching remembers exact scroll offsets and active ancestor selection so grandfather never has to hunt for where he left off.
  - **Senior Accessibility**: High contrast, warm archival paper tones, clean readable typography (Lora / Source Serif for the book; Plus Jakarta Sans for the research UI), and adjustable text zoom (Standard, Large, Extra Large).

- **Target Audience / Persona**:
  - Grandfathers and family historians writing multi-chapter memoirs and family biographies who want an easy-to-use, legible tool without overwhelming software bloat.

- **Key Value**:
  - Eliminates the frustration of tab juggling between complex genealogy sites and separate word processors; compiles duplicate facts cleanly with proof citations right at his fingertips.

---

### 2. User Experience & Visual Design

#### Visual Identity & Theme
- **Aesthetic Direction**: Archival editorial craftsmanship meets modern minimalist Google Docs utility.
- **Palette**:
  - Canvas: Archival warm paper (`#FBF9F5` in research, `#FFFFFF` crisp sheet on `#F1EFEA` backdrop in editor).
  - Surfaces: Clean hairline borders (`border-stone-200`), warm limestone panels (`#F4F1EA`), and crisp white document pages.
  - Text: High-contrast antique charcoal (`#1C1917`) ensuring WCAG AAA legibility for senior eyes.
  - Accents: 
    - FamilySearch Blue: `#0076CE`
    - Ancestry Forest Green: `#1D7044`
    - Curatorial Amber/Bronze: `#B45309` for citations and verified proof markers.
- **Typography**:
  - Book Manuscript: *Lora* / *Source Serif 4* with comfortable 1.8 line height and 68ch line measure.
  - Controls & Metadata: *Plus Jakarta Sans* with clean single-line labels and clear visual touch targets ($\ge 44\text{px}$).
  - Numeric Dates & Census Years: Monospace tabular numerals (`font-mono tabular-nums`) for clean chronological alignment.

#### Key User Flows
1. **Research & Verify**:
   - Grandfather selects an ancestor (or imports his `.ged` tree / connects FamilySearch).
   - He browses the deduplicated life timeline from birth to passing.
   - For any fact (e.g. "1910 US Federal Census, Boston, MA"), he sees both `[FamilySearch]` and `[Ancestry]` proof tags.
   - Clicking a proof link opens the exact record or search query on the respective site in a new tab for instant verification.
   - Clicking "Cite in Book" copies or directly injects an academic or narrative footnote citation into his book.
2. **Switching to Write**:
   - Grandfather clicks "My Manuscript Book" tab.
   - The app instantly restores his exact scroll position, zoom level, and editor cursor.
   - The document displays his chapters, formatting ribbon, and footnotes.
   - Auto-save silently persists every keystroke to local storage.
3. **Switching Back to Research**:
   - Switching back to "Research" instantly returns to the exact ancestor and timeline event he was inspecting.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Client-Side GEDCOM Parser & Real External Query Generator**
  - *Chosen Approach*: Implement a robust browser-based parser for standard `.ged` family tree files (supports INDI, FAM, BIRT, DEAT, BURI, MARR, RESI, SOUR) alongside pre-configured rich multi-generation family records and live link-outs to Ancestry and FamilySearch search engines.
  - *Why*: Ancestry.com does not provide a public open OAuth 2.0 API for third-party consumer web apps. Providing real GEDCOM file import plus automated deep-linking (`familysearch.org/search/record/results` and `ancestry.com/search`) gives grandfather real access to his data without brittle scraping or unmaintained scrapers.
- **Decision 2: Smart Deduplication Algorithm**
  - *Chosen Approach*: Multi-attribute entity matching based on normalized date (year/month/day), location tokens (city, county, state), and event type (Birth, Baptism, Marriage, Census, Military, Death, Burial).
  - *Why*: When both sites list the same 1892 birth in Boston, grandfather shouldn't have to read two identical entries. Merged entries display both source badges and unified citations.
- **Decision 3: Scroll & Focus Persistence**
  - *Chosen Approach*: Track DOM scroll positions (`scrollTop`), active ancestor ID, and active section on unmount/tab-switch, and restore them via `useLayoutEffect` / `requestAnimationFrame`.
  - *Why*: Directly solves the user's specific request: "save his last place on each so he doesnt have to scroll too much."

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        KinScribe Root Layout                           │
│  - Senior Accessibility Bar (Font Size: Standard / Large / XL)         │
│  - Persistent Tab Bar: [📖 My Manuscript Book]  [🌳 Genealogy Research]│
│  - Auto-Save Status: "All changes saved locally"                       │
└──────────────────┬─────────────────────────────────┬───────────────────┘
                   │                                 │
                   ▼                                 ▼
┌───────────────────────────────────┐ ┌──────────────────────────────────┐
│        Tab 1: Manuscript          │ │        Tab 2: Research           │
│    (Google Docs Style Editor)     │ │   (Deduplicated Timeline View)   │
├───────────────────────────────────┤ ├──────────────────────────────────┤
│ - Rich Formatting Ribbon          │ │ - Account & Source Status Bar:   │
│   (Undo/Redo, Headings, Bold,     │ │   • FamilySearch (Connected)     │
│    Italic, Underline, Align,      │ │   • Ancestry (Imported / Sync)   │
│    Lists, Blockquote, Page Break) │ │ - GEDCOM File Upload (.ged)      │
│ - Document Outline & Chapter Tree │ │ - Ancestor Selector & Search     │
│ - Google Docs Page Canvas         │ │ - Deduplicated Life Timeline     │
│ - Footnotes & Citations Panel     │ │   • Verified Event Cards         │
│ - Export to DOCX / PDF / Print    │ │   • Source Badges (FS / Ancestry)│
│ - Scroll Position Restorer        │ │   • Clickable Verification Links │
│                                   │ │   • "Insert Citation" Action     │
│                                   │ │ - Scroll Position Restorer       │
└───────────────────────────────────┘ └──────────────────────────────────┘
                   │                                 │
                   └────────────────┬────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Persistence & Storage                           │
│  - localStorage / IndexedDB: Auto-saved manuscript drafts, chapters    │
│  - State Engine: Scroll offset cache (bookScrollY, researchScrollY)    │
│  - Genealogy Store: Deduplicated timeline events & source citations    │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Data Entities
- `Ancestor`: `id`, `name`, `birthYear`, `deathYear`, `relationship`, `avatarUrl`, `treeBranch`.
- `TimelineEvent`: `id`, `ancestorId`, `type` (`birth` | `residence` | `census` | `military` | `marriage` | `death`), `date`, `place`, `description`, `sources`: `Array<{ provider: 'familysearch' | 'ancestry', recordTitle: '1910 Federal Census', url: string, citationText: string }>`.
- `ManuscriptChapter`: `id`, `title`, `contentHtml`, `wordCount`, `lastModified`.
- `CitationFootnote`: `id`, `eventRefId`, `shortCite`, `fullCitation`, `sourceUrl`.

---

### 5. Implementation Sequence (Post-Approval)

1. **Foundations & Icons**:
   - Install required packages (e.g. rich text editor helper or robust contenteditable framework with clean command execution).
   - Configure typography and theme variables in `src/index.css`.
2. **Genealogy Engine & Deduplication**:
   - Implement GEDCOM 5.5.1 parser and smart fact deduplicator.
   - Build seed records with authentic historical documents (Ellis Island passenger manifests, WWI draft cards, US Censuses, parish registers).
   - Create external verification URL builders for FamilySearch and Ancestry search queries.
3. **Research Workspace Component**:
   - FamilySearch / Ancestry connection cards and status badges.
   - Ancestor selector and filter.
   - Chronological life timeline with side-by-side or merged source proof links.
4. **Google Docs-Style Book Writing App**:
   - Toolbar ribbon with full rich-text controls.
   - Page margins, ruler styling, word counter, and chapters outline.
   - Footnote citation manager with direct sync from the research timeline.
5. **Senior UX & Scroll Position Memory**:
   - Scroll position capture and automatic restoration on tab switch.
   - Adjustable UI scale (Standard / Senior Large / Extra Large).
   - Auto-saving to browser storage with status indicator.
6. **Verification & Testing**:
   - Test GEDCOM import, deduplication logic, rich text formatting, citation insertion, scroll position preservation across tab switches, and responsive layout.
