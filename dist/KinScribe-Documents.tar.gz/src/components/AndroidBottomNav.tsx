import React from 'react';
import { BookOpen, Search, Mic, Compass, Sparkles } from 'lucide-react';

interface Props {
  activeTab: 'writer' | 'research' | 'chat';
  onSelectTab: (tab: 'writer' | 'research' | 'chat') => void;
  onOpenSearchAssistant?: () => void;
  onOpenVoiceRecorder?: () => void;
  onShare?: () => void;
}

export const AndroidBottomNav: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  onOpenSearchAssistant,
  onOpenVoiceRecorder
}) => {
  return (
    <nav 
      aria-label="Mobile Navigation"
      className="sticky bottom-0 left-0 right-0 z-40 bg-[#161412]/95 backdrop-blur-md border-t border-stone-800/80 text-stone-300 px-3 py-1.5 flex items-center justify-between shadow-2xl no-print"
    >
      <div className="flex items-center gap-1.5 w-full max-w-md mx-auto justify-around">
        
        {/* Tab 1: Manuscript Writer */}
        <button
          onClick={() => onSelectTab('writer')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all ${
            activeTab === 'writer'
              ? 'bg-amber-600/30 text-amber-300 font-bold border border-amber-500/40 shadow-xs'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/50 font-medium'
          }`}
          title="Manuscript Book Writer"
        >
          <BookOpen className={`w-4 h-4 ${activeTab === 'writer' ? 'text-amber-400' : 'text-stone-400'}`} />
          <span>My Book</span>
        </button>

        {/* Tab 2: Genealogy Research */}
        <button
          onClick={() => onSelectTab('research')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all ${
            activeTab === 'research'
              ? 'bg-amber-600/30 text-amber-300 font-bold border border-amber-500/40 shadow-xs'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/50 font-medium'
          }`}
          title="Genealogy Research & Timeline"
        >
          <Search className={`w-4 h-4 ${activeTab === 'research' ? 'text-amber-400' : 'text-stone-400'}`} />
          <span>Research</span>
        </button>

        {/* Tab 3: Archival Fact Chat */}
        <button
          onClick={() => onSelectTab('chat')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs transition-all ${
            activeTab === 'chat'
              ? 'bg-amber-600/30 text-amber-300 font-bold border border-amber-500/40 shadow-xs'
              : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/50 font-medium'
          }`}
          title="Archival Fact-Checker & Google Grounding"
        >
          <Sparkles className={`w-4 h-4 ${activeTab === 'chat' ? 'text-amber-400' : 'text-stone-400'}`} />
          <span>Fact Chat</span>
        </button>

        {/* Quick Voice / Oral Memories Recording shortcut */}
        {onOpenVoiceRecorder && (
          <button
            onClick={onOpenVoiceRecorder}
            className="p-2 rounded-full text-stone-400 hover:text-red-400 hover:bg-stone-800/60 transition-colors"
            title="Record Oral Memory Dictation"
          >
            <Mic className="w-4 h-4 text-red-400" />
          </button>
        )}

        {/* Quick Search Assistant */}
        {onOpenSearchAssistant && (
          <button
            onClick={onOpenSearchAssistant}
            className="p-2 rounded-full text-stone-400 hover:text-amber-300 hover:bg-stone-800/60 transition-colors"
            title="Quick Archival Search"
          >
            <Compass className="w-4 h-4 text-amber-500" />
          </button>
        )}

      </div>
    </nav>
  );
};
