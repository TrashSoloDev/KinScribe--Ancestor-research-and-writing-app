import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Sparkles, 
  Search, 
  ExternalLink, 
  BookOpen, 
  ShieldCheck, 
  AlertCircle, 
  RotateCcw, 
  Copy, 
  Check, 
  FileText, 
  Plus, 
  Globe, 
  BrainCircuit, 
  Zap, 
  Cpu,
  Info
} from 'lucide-react';
import { ManuscriptChapter, Ancestor } from '../types/genealogy';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  sources?: { title: string; uri: string }[];
  modelUsed?: string;
  isError?: boolean;
}

interface Props {
  documentTitle: string;
  chapters: ManuscriptChapter[];
  activeChapterId: string;
  ancestors: Ancestor[];
  onInsertToChapter?: (text: string, sourceNotes?: string) => void;
}

const STARTER_PROMPTS = [
  'Fact-check whether motor launches existed in Fitts Village before 1950',
  'Verify 1921 Barbados Census records for St. James Parish boatwrights',
  'What primary repository holds 1890s Barbados deeds for Samuel Scott?',
  'Check chronological consistency of marriage banns vs sacramental registration'
];

export const ArchivalChatTab: React.FC<Props> = ({
  documentTitle,
  chapters,
  activeChapterId,
  ancestors,
  onInsertToChapter
}) => {
  const activeChapter = chapters.find(c => c.id === activeChapterId) || chapters[0];

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome_1',
      role: 'model',
      text: `ARCHIVAL FACT-CHECKING STATION ONLINE
I am the strict, objective historical research assistant for "${documentTitle}".

OPERATIONAL DIRECTIVES:
• Reputable & fact-based: All responses are grounded in verified colonial records, Anglican Sacristy registers, 1921 Census schedules, and historical documentation.
• No emotional validation: I will not flatter, soothe, or validate genealogical assumptions without primary evidence.
• Error identification: If an assertion or date contradicts historical archives or chronological realities, I will state the contradiction plainly.
• Google Search Grounding: Live web verification is enabled to cross-reference real-world historical dates, locations, and legislation.

How can I assist your manuscript research today?`,
      timestamp: 'Ready',
      modelUsed: 'Archival Grounding'
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.8-flash');
  const [searchGroundingEnabled, setSearchGroundingEnabled] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [insertedId, setInsertedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const formatModeLabel = (m?: string) => {
    if (!m) return 'Archival Grounding';
    if (m.includes('carbon')) return 'Deep Verification';
    if (m.includes('lite')) return 'Quick Lookup';
    if (m.includes('argon')) return 'Complex Analysis';
    return 'Archival Grounding';
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputPrompt).trim();
    if (!query || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInputPrompt('');
    setIsLoading(true);

    try {
      // Build current book context for archival researcher
      const ancestorsSummary = ancestors
        .slice(0, 5)
        .map(a => `${a.name} (${a.birthYear}-${a.deathYear}, ${a.relationship})`)
        .join('; ');

      const chapterSnippet = activeChapter?.contentHtml
        ? activeChapter.contentHtml.replace(/<[^>]*>/g, ' ').slice(0, 800)
        : '';

      const resp = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: newHistory.map(m => ({
            role: m.role,
            text: m.text
          })),
          bookContext: {
            documentTitle,
            chapterTitle: activeChapter?.title || 'Untitled Chapter',
            chapterSnippet,
            ancestorsSummary
          },
          model: selectedModel,
          enableSearch: searchGroundingEnabled
        })
      });

      if (!resp.ok) {
        throw new Error(`Server returned status ${resp.status}`);
      }

      const data = await resp.json();

      const assistantMessage: ChatMessage = {
        id: `asst_${Date.now()}`,
        role: 'model',
        text: data.text || 'No response recorded.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: data.sources || [],
        modelUsed: data.modelUsed || selectedModel
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat request failed:', err);
      const errorMessage: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'model',
        text: `FACT-CHECKING NOTICE:
Unable to connect to live archival reasoning service (${err?.message || 'Network disruption'}).
Please ensure your query targets specific historical records, dates, or terminology, and verify server connection.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleInsertFact = (id: string, text: string, sources?: { title: string; uri: string }[]) => {
    if (!onInsertToChapter) return;
    const sourceText = sources && sources.length > 0 
      ? `\nSources Verified: ${sources.map(s => `${s.title} (${s.uri})`).join('; ')}`
      : '';
    onInsertToChapter(text, sourceText);
    setInsertedId(id);
    setTimeout(() => setInsertedId(null), 2500);
  };

  const handleClearHistory = () => {
    if (confirm('Clear research conversation thread?')) {
      setMessages([
        {
          id: `welcome_${Date.now()}`,
          role: 'model',
          text: `Thread reset. Ready to fact-check dates, colonial records, and historical context for "${documentTitle}".`,
          timestamp: 'Reset',
          modelUsed: selectedModel
        }
      ]);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-130px)] md:h-[calc(100vh-115px)] bg-[#FAF8F5] max-w-6xl mx-auto border-x border-stone-200 shadow-sm">
      
      {/* Sleek Top Control Bar */}
      <div className="bg-white border-b border-stone-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Chat Title & Strict Disciplinary Subtitle */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-stone-900 text-amber-300 flex items-center justify-center shadow-xs">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold font-serif-book text-stone-900 leading-tight">
                Archival Fact-Checker & Google Grounding
              </h2>
              <span className="text-[10px] uppercase font-mono-data tracking-wider bg-stone-100 text-stone-700 px-1.5 py-0.5 rounded border border-stone-300">
                Objective Scholarly Mode
              </span>
            </div>
            <p className="text-[11px] text-stone-500 font-sans-ui mt-0.5">
              Tied to <strong className="text-stone-800">"{activeChapter?.title}"</strong> · Reputable archival records only · Zero emotional validation
            </p>
          </div>
        </div>

        {/* Right: Model Selector & Grounding Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Research Mode Switcher */}
          <div className="flex items-center bg-stone-100 p-0.5 rounded-xl border border-stone-200 text-xs">
            <button
              onClick={() => setSelectedModel('gemini-3.8-flash')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                selectedModel === 'gemini-3.8-flash' 
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
              title="Fact Grounding: Live Google Search and archival record lookup"
            >
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>Fact Grounding</span>
            </button>

            <button
              onClick={() => setSelectedModel('gemini-4-carbon')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                selectedModel === 'gemini-4-carbon' 
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
              title="Deep Verification: In-depth lineage and chronological contradiction analysis"
            >
              <BrainCircuit className="w-3.5 h-3.5 text-purple-600" />
              <span>Deep Verification</span>
            </button>

            <button
              onClick={() => setSelectedModel('gemini-3.1-flash-lite')}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg font-medium transition-all cursor-pointer ${
                selectedModel === 'gemini-3.1-flash-lite' 
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold' 
                  : 'text-stone-600 hover:text-stone-900'
              }`}
              title="Quick Lookup: Fast verification of parish terms and historical dates"
            >
              <Zap className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Quick Lookup</span>
            </button>
          </div>

          {/* Search Grounding Checkbox (active when using 3.8 flash) */}
          {selectedModel === 'gemini-3.8-flash' && (
            <label className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-900 border border-blue-200/80 rounded-lg text-xs cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={searchGroundingEnabled}
                onChange={e => setSearchGroundingEnabled(e.target.checked)}
                className="rounded text-blue-600 focus:ring-blue-500 h-3.5 w-3.5"
              />
              <span className="flex items-center gap-1">
                <Search className="w-3 h-3 text-blue-700" />
                Google Search
              </span>
            </label>
          )}

          {/* Reset Thread */}
          <button
            onClick={handleClearHistory}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
            title="Reset Conversation Thread"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Book Context Banner */}
      <div className="bg-[#F3EFE6] border-b border-stone-200/80 px-4 py-2 flex items-center justify-between text-xs text-stone-700">
        <div className="flex items-center gap-2 truncate">
          <BookOpen className="w-3.5 h-3.5 text-amber-800 shrink-0" />
          <span className="text-stone-500">Active Book Context:</span>
          <span className="font-semibold text-stone-900 truncate">
            {documentTitle} → {activeChapter?.title}
          </span>
        </div>
        <div className="text-[11px] font-mono-data text-stone-500 shrink-0 hidden sm:block">
          {ancestors.length} Ancestors Loaded · {chapters.length} Chapters
        </div>
      </div>

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-full`}
            >
              {/* Message Header */}
              <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-stone-400">
                <span className="font-semibold text-stone-600">
                  {isUser ? 'Author (Ward Scott)' : 'Archival Fact-Checker'}
                </span>
                <span>·</span>
                <span className="font-mono-data">{msg.timestamp}</span>
                {msg.modelUsed && !isUser && (
                  <>
                    <span>·</span>
                    <span className="font-mono-data text-[10px] text-stone-600 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">
                      {formatModeLabel(msg.modelUsed)}
                    </span>
                  </>
                )}
              </div>

              {/* Message Bubble */}
              <div
                className={`rounded-2xl p-4 sm:p-5 max-w-3xl text-sm leading-relaxed shadow-xs transition-all ${
                  isUser
                    ? 'bg-amber-800 text-white rounded-tr-xs'
                    : msg.isError
                    ? 'bg-red-50 text-red-950 border border-red-200 rounded-tl-xs'
                    : 'bg-white text-stone-900 border border-stone-300 rounded-tl-xs font-serif-book'
                }`}
              >
                {/* Text Content */}
                <div className="whitespace-pre-wrap select-text font-serif-book">
                  {msg.text}
                </div>

                {/* Grounded Web Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-stone-200 font-sans-ui text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-stone-800 mb-2">
                      <Search className="w-3.5 h-3.5 text-blue-600" />
                      <span>Verified Google Search & Archival Sources ({msg.sources.length})</span>
                    </div>
                    <ul className="space-y-1.5">
                      {msg.sources.map((src, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="font-mono-data text-stone-400 text-[10px] mt-0.5">[{i + 1}]</span>
                          <a
                            href={src.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-700 hover:text-blue-900 underline inline-flex items-center gap-1 font-medium break-all"
                          >
                            <span>{src.title}</span>
                            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Assistant Message Actions: Copy & Insert into Chapter */}
              {!isUser && !msg.isError && (
                <div className="flex items-center gap-2 mt-1.5 px-1">
                  <button
                    onClick={() => handleCopyText(msg.id, msg.text)}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs text-stone-600 hover:text-stone-900 hover:bg-stone-200/80 rounded-lg transition-colors cursor-pointer"
                    title="Copy response text"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>

                  {onInsertToChapter && (
                    <button
                      onClick={() => handleInsertFact(msg.id, msg.text, msg.sources)}
                      className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold bg-amber-100 hover:bg-amber-200 text-amber-950 rounded-lg border border-amber-300 transition-colors shadow-2xs cursor-pointer"
                      title="Insert this verified archival finding into your active manuscript chapter"
                    >
                      {insertedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-700" />
                          <span className="text-emerald-800">Inserted into Draft!</span>
                        </>
                      ) : (
                        <>
                          <FileText className="w-3.5 h-3.5 text-amber-800" />
                          <span>Insert into Chapter</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex flex-col items-start max-w-xl">
            <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-stone-400">
              <span className="font-semibold text-stone-600">Archival Fact-Checker</span>
              <span>·</span>
              <span>Grounding with Google Search & Archives...</span>
            </div>
            <div className="bg-white border border-stone-300 rounded-2xl rounded-tl-xs p-4 shadow-xs flex items-center gap-3">
              <div className="w-5 h-5 rounded-full border-2 border-amber-700 border-t-transparent animate-spin" />
              <div className="text-xs text-stone-700 font-sans-ui space-y-0.5">
                <p className="font-semibold text-stone-900">Querying verified primary records & Google Search...</p>
                <p className="text-[11px] text-stone-500">Checking colonial schedules, parish sacristy data, and chronological invariants</p>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Fact-Check Queries */}
      <div className="px-4 py-2 bg-stone-50 border-t border-stone-200/80 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 shrink-0">
          Archival Inquiries:
        </span>
        {STARTER_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            disabled={isLoading}
            className="px-2.5 py-1 text-xs bg-white hover:bg-stone-100 disabled:opacity-50 text-stone-700 rounded-lg border border-stone-200/90 whitespace-nowrap transition-colors shrink-0 cursor-pointer shadow-2xs"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Bottom Input Area */}
      <div className="p-3 sm:p-4 bg-white border-t border-stone-200 shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-end gap-2"
        >
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              rows={2}
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Ask a factual genealogy question or paste a claim to fact-check against primary archives..."
              className="w-full p-3 text-xs sm:text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-600 focus:bg-white text-stone-900 resize-none font-sans-ui placeholder:text-stone-400"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading || !inputPrompt.trim()}
            className="p-3 bg-amber-800 hover:bg-amber-900 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors shrink-0 flex items-center justify-center cursor-pointer"
            title="Send query to Fact-Checker (Enter)"
          >
            <Send className="w-5 h-5 text-amber-100" />
          </button>
        </form>

        <div className="mt-2 flex items-center justify-between text-[11px] text-stone-400 px-1">
          <span className="flex items-center gap-1">
            <Info className="w-3 h-3 text-amber-700" />
            Rigorous fact-checking mode active: assertions without archival evidence are flagged as unverified.
          </span>
          <span className="hidden sm:inline font-mono-data">Press Enter to send · Shift+Enter for newline</span>
        </div>
      </div>

    </div>
  );
};
