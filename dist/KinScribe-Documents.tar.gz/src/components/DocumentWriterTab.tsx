import React, { useState, useRef, useEffect } from 'react';
import { 
  ManuscriptChapter, 
  CitationFootnote, 
  TimelineFact,
  RecordSource,
  Ancestor,
  HistoricalSearchQuery
} from '../types/genealogy';
import { 
  Undo, 
  Redo, 
  Bold, 
  Italic, 
  Underline, 
  Strikethrough, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify, 
  List, 
  ListOrdered, 
  Quote, 
  Minus, 
  Plus, 
  Printer, 
  Download, 
  BookMarked, 
  ExternalLink, 
  PlusCircle, 
  Trash2, 
  ChevronLeft, 
  ChevronRight, 
  FileText,
  Search,
  Check,
  Sparkles,
  Bookmark,
  ChevronUp,
  ChevronDown,
  X,
  ArrowDownUp,
  SlidersHorizontal,
  Mic,
  Compass,
  Camera,
  BookOpen,
  UploadCloud,
  FileUp,
  FileCode,
  FileType,
  FileDown
} from 'lucide-react';
import { parseUploadedManuscriptFile, ImportedManuscript } from '../utils/manuscriptImporter';
import { GroundingSidebar, GroundingResult } from './GroundingSidebar';
import { LookUpPopover } from './LookUpPopover';
import { ChapterPdfExportModal } from './ChapterPdfExportModal';

interface Props {
  chapters: ManuscriptChapter[];
  activeChapterId: string;
  onSelectChapter: (id: string) => void;
  onUpdateChapterContent: (chapterId: string, newHtml: string, wordCount: number) => void;
  onAddChapter: () => void;
  onDeleteChapter: (chapterId: string) => void;
  citations: CitationFootnote[];
  allFacts: TimelineFact[];
  ancestors: Ancestor[];
  fontSizeScale: 'standard' | 'large' | 'xlarge';
  documentTitle: string;
  onUpdateDocumentTitle: (newTitle: string) => void;
  onImportManuscript?: (imported: ImportedManuscript) => void;
  onOpenVoiceRecorder?: () => void;
  onOpenMapModal?: () => void;
  onOpenScrapbookModal?: () => void;
  onOpenKDPModal?: () => void;
  recentSearches?: HistoricalSearchQuery[];
  onAddRecentSearch?: (query: HistoricalSearchQuery) => void;
  onOpenChatTab?: () => void;
}

export const DocumentWriterTab: React.FC<Props> = ({
  chapters,
  activeChapterId,
  onSelectChapter,
  onUpdateChapterContent,
  onAddChapter,
  onDeleteChapter,
  citations,
  allFacts,
  ancestors,
  fontSizeScale,
  documentTitle,
  onUpdateDocumentTitle,
  onImportManuscript,
  onOpenVoiceRecorder,
  onOpenMapModal,
  onOpenScrapbookModal,
  onOpenKDPModal,
  recentSearches = [],
  onAddRecentSearch,
  onOpenChatTab
}) => {

  const editorRef = useRef<HTMLDivElement>(null);
  const [showFactInserter, setShowFactInserter] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [editorFontFamily, setEditorFontFamily] = useState<'serif' | 'sans' | 'mono'>('serif');
  const [customFontSize, setCustomFontSize] = useState<number>(16);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  // Search & Replace State
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [showReplace, setShowReplace] = useState(false);
  const [matchCase, setMatchCase] = useState(false);
  const [searchScope, setSearchScope] = useState<'chapter' | 'all-chapters'>('chapter');
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);
  const [totalMatches, setTotalMatches] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // File Upload State & Dropzone
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Google Search Grounding State
  const [selectedTerm, setSelectedTerm] = useState<string>('');
  const [selectionContext, setSelectionContext] = useState<string>('');
  const [floatingGroundingBtn, setFloatingGroundingBtn] = useState<{ x: number; y: number } | null>(null);
  const [isGroundingOpen, setIsGroundingOpen] = useState(false);
  const [groundingLoading, setGroundingLoading] = useState(false);
  const [groundingResult, setGroundingResult] = useState<GroundingResult | null>(null);
  const [groundingError, setGroundingError] = useState<string | null>(null);

  // Dictionary & Historical Terminology Lookup State
  const [lookupWord, setLookupWord] = useState<string>('');
  const [lookupContext, setLookupContext] = useState<string>('');
  const [lookupRect, setLookupRect] = useState<DOMRect | null>(null);
  const [isLookupOpen, setIsLookupOpen] = useState(false);

  // Long-press refs
  const longPressTimerRef = useRef<number | null>(null);
  const pointerStartPosRef = useRef<{ x: number; y: number } | null>(null);

  // Clean up long-press timer on unmount
  useEffect(() => {
    return () => {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
      }
    };
  }, []);

  // Helper to extract word and bounding rect at client coordinates
  const getWordAtPoint = (x: number, y: number): { word: string; rect: DOMRect; context: string } | null => {
    let range: Range | null = null;
    const doc = document as any;

    if (doc.caretRangeFromPoint) {
      range = doc.caretRangeFromPoint(x, y);
    } else if (doc.caretPositionFromPoint) {
      const pos = doc.caretPositionFromPoint(x, y);
      if (pos) {
        range = document.createRange();
        range.setStart(pos.offsetNode, pos.offset);
        range.collapse(true);
      }
    }

    if (!range) return null;
    const node = range.startContainer;
    if (!node || node.nodeType !== Node.TEXT_NODE || !node.textContent) {
      return null;
    }

    const text = node.textContent;
    let offset = range.startOffset;
    if (offset >= text.length) offset = Math.max(0, text.length - 1);

    const isWordChar = (char: string) => /[a-zA-Z0-9\u00C0-\u024F'-]/.test(char);
    if (!isWordChar(text[offset])) {
      if (offset > 0 && isWordChar(text[offset - 1])) {
        offset--;
      } else if (offset + 1 < text.length && isWordChar(text[offset + 1])) {
        offset++;
      } else {
        return null;
      }
    }

    let start = offset;
    while (start > 0 && isWordChar(text[start - 1])) {
      start--;
    }

    let end = offset;
    while (end < text.length && isWordChar(text[end])) {
      end++;
    }

    // Clean leading or trailing single quotes or hyphens
    let cleanStart = start;
    let cleanEnd = end;
    while (cleanStart < cleanEnd && /['-]$/.test(text[cleanStart])) {
      cleanStart++;
    }
    while (cleanEnd > cleanStart && /^['-]$/.test(text[cleanEnd - 1])) {
      cleanEnd--;
    }

    const word = text.slice(cleanStart, cleanEnd).trim();
    if (word.length < 2) return null;

    try {
      const wordRange = document.createRange();
      wordRange.setStart(node, cleanStart);
      wordRange.setEnd(node, cleanEnd);
      const rect = wordRange.getBoundingClientRect();
      const parentText = node.parentElement?.innerText || text;
      return {
        word,
        rect,
        context: parentText.slice(0, 300)
      };
    } catch {
      return null;
    }
  };

  const triggerWordLookup = (word: string, rect: DOMRect, context?: string) => {
    const cleanWord = word.trim().replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$/g, '');
    if (!cleanWord || cleanWord.length < 2) return;

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(35);
      } catch {
        // Ignore if restricted
      }
    }

    setLookupWord(cleanWord);
    setLookupContext(context || '');
    setLookupRect(rect);
    setIsLookupOpen(true);
    setFloatingGroundingBtn(null);
  };

  // Touch handlers for mobile long-press
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    pointerStartPosRef.current = { x: touch.clientX, y: touch.clientY };

    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }

    longPressTimerRef.current = window.setTimeout(() => {
      const match = getWordAtPoint(touch.clientX, touch.clientY);
      if (match) {
        triggerWordLookup(match.word, match.rect, match.context);
      }
    }, 450);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!pointerStartPosRef.current || !e.touches[0]) return;
    const dx = Math.abs(e.touches[0].clientX - pointerStartPosRef.current.x);
    const dy = Math.abs(e.touches[0].clientY - pointerStartPosRef.current.y);
    if (dx > 10 || dy > 10) {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
    }
  };

  const handleTouchEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // Mouse handlers for desktop long-press hold
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const clientX = e.clientX;
    const clientY = e.clientY;
    pointerStartPosRef.current = { x: clientX, y: clientY };

    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }

    longPressTimerRef.current = window.setTimeout(() => {
      const match = getWordAtPoint(clientX, clientY);
      if (match) {
        triggerWordLookup(match.word, match.rect, match.context);
      }
    }, 500);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!pointerStartPosRef.current) return;
    const dx = Math.abs(e.clientX - pointerStartPosRef.current.x);
    const dy = Math.abs(e.clientY - pointerStartPosRef.current.y);
    if (dx > 8 || dy > 8) {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
    }
  };

  const handleMouseUp = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // Selection change listener for text highlighting
  const handleEditorSelection = () => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !editorRef.current) {
      return;
    }

    if (!editorRef.current.contains(selection.anchorNode)) {
      return;
    }

    const text = selection.toString().trim();
    if (text.length >= 2 && text.length <= 80) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      setSelectedTerm(text);

      const anchorNode = selection.anchorNode;
      const parentText = anchorNode?.parentElement?.innerText || anchorNode?.textContent || '';
      setSelectionContext(parentText.slice(0, 300));

      setFloatingGroundingBtn({
        x: Math.max(20, rect.left + rect.width / 2),
        y: Math.max(10, rect.top - 12)
      });
    } else {
      setFloatingGroundingBtn(null);
    }
  };

  const triggerSearchGrounding = async (termToSearch?: string) => {
    const term = (termToSearch || selectedTerm).trim();
    if (!term) return;

    setSelectedTerm(term);
    setFloatingGroundingBtn(null);
    setIsGroundingOpen(true);
    setGroundingLoading(true);
    setGroundingError(null);

    try {
      const resp = await fetch('/api/grounding/search-context', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          term,
          context: selectionContext || activeChapter?.title || ''
        })
      });

      if (!resp.ok) {
        throw new Error(`Lookup returned status ${resp.status}`);
      }

      const data = await resp.json();
      setGroundingResult(data);

      onAddRecentSearch?.({
        id: `search_${Date.now()}`,
        term,
        context: selectionContext || activeChapter?.title || '',
        timestamp: 'Just now',
        createdAt: Date.now(),
        resultSnippet: data.explanation ? (data.explanation.slice(0, 160) + '...') : 'Grounded historical background.',
        fullExplanation: data.explanation,
        sources: data.sources || []
      });
    } catch (err: any) {
      console.error('Grounding lookup error:', err);
      setGroundingError(err?.message || 'Unable to retrieve historical search background. Please try again.');
    } finally {
      setGroundingLoading(false);
    }
  };

  const handleInsertGroundingToDraft = (snippet: string) => {
    if (!editorRef.current || !activeChapter) return;
    const blockHtml = `<blockquote class="historical-context-callout p-3.5 my-3 bg-blue-50/70 border-l-4 border-blue-600 rounded-r-lg font-serif text-stone-800 text-sm leading-relaxed shadow-2xs"><strong>Historical Note (${selectedTerm}):</strong> ${snippet}</blockquote><p><br/></p>`;
    editorRef.current.innerHTML += blockHtml;
    handleInput();
  };

  const handleInsertLookupToDraft = (snippetHtml: string) => {
    if (!editorRef.current || !activeChapter) return;
    editorRef.current.innerHTML += snippetHtml;
    handleInput();
  };

  const handleProcessFile = async (file: File) => {
    setIsUploading(true);
    setUploadError(null);
    try {
      const parsed = await parseUploadedManuscriptFile(file);
      if (onImportManuscript) {
        onImportManuscript(parsed);
      } else if (activeChapter) {
        // Fallback if prop not provided: apply first chapter to active chapter
        if (parsed.chapters[0]) {
          activeChapter.title = parsed.chapters[0].title;
          activeChapter.contentHtml = parsed.chapters[0].contentHtml;
          activeChapter.wordCount = parsed.chapters[0].wordCount;
          if (editorRef.current) {
            editorRef.current.innerHTML = parsed.chapters[0].contentHtml;
          }
          handleInput();
        }
      }
    } catch (err: any) {
      console.error('File import error:', err);
      setUploadError(err?.message || 'Could not import draft file. Please ensure it is a valid .docx, .html, .md, or .txt file.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
    // reset input value so re-uploading same file name triggers change
    if (fileInputRef.current) fileInputRef.current.value = '';
  };


  // Helper to strip highlight mark tags
  const removeMarks = (html: string) => {
    return html.replace(/<mark id="search-match-\d+" class="[^"]*">(.*?)<\/mark>/g, '$1');
  };

  const clearHighlights = () => {
    if (editorRef.current) {
      editorRef.current.innerHTML = removeMarks(editorRef.current.innerHTML);
    }
  };

  // Keyboard shortcut listener for Ctrl+F / Cmd+F and Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setSearchOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 50);
      } else if (e.key === 'Escape' && searchOpen) {
        setSearchOpen(false);
        clearHighlights();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchOpen]);

  // Execute Search & Highlight on current chapter
  const executeSearch = (query: string, activeIdx: number = 0, isCaseSensitive: boolean = matchCase) => {
    if (!editorRef.current || !activeChapter) return;
    
    // Always start from clean content without old marks
    const cleanHtml = removeMarks(editorRef.current.innerHTML);

    if (!query.trim()) {
      editorRef.current.innerHTML = cleanHtml;
      setTotalMatches(0);
      setCurrentMatchIndex(0);
      return;
    }

    const flags = isCaseSensitive ? 'g' : 'gi';
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let matchCount = 0;

    // Split by HTML tags to only highlight text nodes
    const parts = cleanHtml.split(/(<[^>]*>)/);
    const highlightedParts = parts.map(part => {
      if (part.startsWith('<') && part.endsWith('>')) {
        return part;
      }
      const regex = new RegExp(escaped, flags);
      return part.replace(regex, (match) => {
        const isCurrent = matchCount === activeIdx;
        const id = `search-match-${matchCount}`;
        matchCount++;
        const styleClass = isCurrent
          ? 'bg-amber-400 text-stone-900 font-bold px-1 py-0.5 rounded shadow-xs ring-2 ring-amber-600'
          : 'bg-yellow-200 text-stone-900 px-0.5 rounded';
        return `<mark id="${id}" class="${styleClass}">${match}</mark>`;
      });
    });

    editorRef.current.innerHTML = highlightedParts.join('');
    setTotalMatches(matchCount);

    if (matchCount > 0) {
      const validIndex = activeIdx >= matchCount ? 0 : activeIdx;
      setCurrentMatchIndex(validIndex);
      setTimeout(() => {
        const activeEl = document.getElementById(`search-match-${validIndex}`);
        if (activeEl) {
          activeEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 50);
    } else {
      setCurrentMatchIndex(0);
    }
  };

  // Re-run search when query or active chapter changes
  useEffect(() => {
    if (searchOpen && searchQuery) {
      executeSearch(searchQuery, currentMatchIndex, matchCase);
    } else if (!searchOpen) {
      clearHighlights();
    }
  }, [searchQuery, matchCase, activeChapterId]);

  const handleNextMatch = () => {
    if (totalMatches === 0) return;
    const nextIdx = (currentMatchIndex + 1) % totalMatches;
    setCurrentMatchIndex(nextIdx);
    executeSearch(searchQuery, nextIdx, matchCase);
  };

  const handlePrevMatch = () => {
    if (totalMatches === 0) return;
    const prevIdx = (currentMatchIndex - 1 + totalMatches) % totalMatches;
    setCurrentMatchIndex(prevIdx);
    executeSearch(searchQuery, prevIdx, matchCase);
  };

  const handleReplaceCurrent = () => {
    if (!editorRef.current || totalMatches === 0) return;
    const activeEl = document.getElementById(`search-match-${currentMatchIndex}`);
    if (activeEl) {
      activeEl.outerHTML = replaceQuery;
      handleInput();
      executeSearch(searchQuery, currentMatchIndex, matchCase);
    }
  };

  const handleReplaceAll = () => {
    if (!editorRef.current || !searchQuery) return;
    const cleanHtml = removeMarks(editorRef.current.innerHTML);
    const flags = matchCase ? 'g' : 'gi';
    const escaped = searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    const parts = cleanHtml.split(/(<[^>]*>)/);
    const replaced = parts.map(part => {
      if (part.startsWith('<') && part.endsWith('>')) return part;
      return part.replace(new RegExp(escaped, flags), replaceQuery);
    }).join('');

    editorRef.current.innerHTML = replaced;
    handleInput();
    executeSearch(searchQuery, 0, matchCase);
  };

  // Search across all chapters in entire book
  const allChapterSearchResults = React.useMemo(() => {
    if (!searchQuery.trim() || searchScope !== 'all-chapters') return [];
    const flags = matchCase ? 'g' : 'gi';
    const escaped = searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(escaped, flags);

    return chapters.map((ch, idx) => {
      const text = removeMarks(ch.contentHtml).replace(/<[^>]*>/g, ' ');
      const matches = text.match(regex);
      if (!matches || matches.length === 0) return null;

      const firstPos = matchCase 
        ? text.indexOf(searchQuery) 
        : text.toLowerCase().indexOf(searchQuery.toLowerCase());
      const start = Math.max(0, firstPos - 35);
      const end = Math.min(text.length, firstPos + searchQuery.length + 45);
      const snippet = text.slice(start, end).trim();

      return {
        chapterId: ch.id,
        chapterIndex: idx + 1,
        title: ch.title,
        matchCount: matches.length,
        snippet: `...${snippet}...`
      };
    }).filter(Boolean);
  }, [chapters, searchQuery, searchScope, matchCase]);

  const activeChapter = chapters.find(c => c.id === activeChapterId) || chapters[0];

  // Sync editor content when activeChapter changes
  useEffect(() => {
    if (editorRef.current && activeChapter) {
      if (editorRef.current.innerHTML !== activeChapter.contentHtml) {
        editorRef.current.innerHTML = activeChapter.contentHtml;
        updateWordCount();
      }
    }
  }, [activeChapterId, activeChapter?.contentHtml]);

  const updateWordCount = () => {
    if (!editorRef.current) return;
    const text = editorRef.current.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    setWordCount(words);
  };

  const handleInput = () => {
    if (!editorRef.current || !activeChapter) return;
    const html = editorRef.current.innerHTML;
    const text = editorRef.current.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    setWordCount(words);
    onUpdateChapterContent(activeChapter.id, html, words);
  };

  const execCmd = (command: string, value: string | undefined = undefined) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      editorRef.current.focus();
    }
    handleInput();
  };

  // Export functions
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadDoc = () => {
    if (!activeChapter) return;
    const fullHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${documentTitle} - ${activeChapter.title}</title>
        <style>
          body { font-family: 'Georgia', serif; line-height: 1.8; margin: 2in; color: #111; }
          h1 { text-align: center; font-size: 24pt; margin-bottom: 24pt; }
          h2 { font-size: 18pt; margin-top: 18pt; }
          p { margin-bottom: 12pt; text-indent: 0.5in; }
          .footnotes { margin-top: 36pt; border-top: 1px solid #ccc; padding-top: 12pt; font-size: 10pt; }
        </style>
      </head>
      <body>
        <h1>${documentTitle}</h1>
        <h2>${activeChapter.title}</h2>
        ${activeChapter.contentHtml}
        <div class="footnotes">
          <h3>Archival Citations & Sources</h3>
          <ul>
            ${citations.map(c => `<li>[${c.number}] ${c.fullCitation} (${c.sourceUrl})</li>`).join('')}
          </ul>
        </div>
      </body>
      </html>
    `;
    const blob = new Blob([fullHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${documentTitle.replace(/\s+/g, '_')}_${activeChapter.title.replace(/\s+/g, '_')}.doc`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadTxt = () => {
    if (!editorRef.current || !activeChapter) return;
    const text = `${documentTitle}\n${activeChapter.title}\n\n${editorRef.current.innerText}\n\n--- ARCHIVAL CITATIONS ---\n` +
      citations.map(c => `[${c.number}] ${c.fullCitation}\nURL: ${c.sourceUrl}\n`).join('\n');
    
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${activeChapter.title.replace(/\s+/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Insert researched fact into text at current cursor
  const handleInsertFact = (fact: TimelineFact, source: RecordSource) => {
    if (!editorRef.current) return;
    editorRef.current.focus();

    const citationNum = citations.length + 1;
    const insertionText = ` According to ${source.provider === 'familysearch' ? 'FamilySearch records' : 'Ancestry.com archives'}, on ${fact.dateStr}, ${fact.description} [${citationNum}]. `;

    execCmd('insertHTML', insertionText);
    setShowFactInserter(false);
  };

  // Dynamic font scale
  const scaleFontSize = 
    fontSizeScale === 'xlarge' ? customFontSize + 4 :
    fontSizeScale === 'large' ? customFontSize + 2 : customFontSize;

  const fontClass = 
    editorFontFamily === 'serif' ? 'font-serif-book' :
    editorFontFamily === 'mono' ? 'font-mono-data' : 'font-sans-ui';

  return (
    <div className="flex flex-col h-full min-h-[calc(100vh-80px)] bg-[#F8F6F0]">
      
      {/* MODERN SLEEK WORKSPACE TOOLBAR (2-Tier Layout: Document Controls & Text Styling) */}
      <div className="bg-[#FAF9F5] border-b border-stone-200/90 shadow-xs flex flex-col no-print shrink-0">
        
        {/* Tier 1: Document Level Navigation & Primary Export Actions */}
        <div className="px-3 sm:px-4 py-2 border-b border-stone-200/70 flex items-center justify-between gap-3 overflow-x-auto no-scrollbar">
          
          {/* Left: Outline Toggle, Chapter Quick Switcher, Document Title */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className={`px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-semibold shrink-0 cursor-pointer ${
                sidebarOpen 
                  ? 'bg-amber-100/90 text-amber-900 border border-amber-300 shadow-2xs' 
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-200'
              }`}
              title={sidebarOpen ? 'Hide Chapter Outline' : 'Show Chapter Outline'}
            >
              <Bookmark className="w-4 h-4 text-amber-800" />
              <span>Chapters ({chapters.length})</span>
            </button>

            {/* Quick Chapter Selector Dropdown */}
            <select
              value={activeChapter?.id}
              onChange={(e) => onSelectChapter(e.target.value)}
              className="bg-white border border-stone-300 rounded-lg px-2.5 py-1 text-xs font-serif-book font-medium text-stone-800 focus:outline-hidden focus:ring-1 focus:ring-amber-500 max-w-[190px] sm:max-w-xs truncate"
              title="Switch Current Chapter"
            >
              {chapters.map((ch, idx) => (
                <option key={ch.id} value={ch.id}>
                  {idx + 1}. {ch.title} ({ch.wordCount.toLocaleString()} w)
                </option>
              ))}
            </select>

            <span className="text-stone-300 hidden md:inline">|</span>

            <span className="text-xs text-stone-500 font-mono-data hidden lg:inline">
              {wordCount.toLocaleString()} words · {citations.length} cited
            </span>
          </div>

          {/* Right: Primary Download as PDF + Author Companion Actions */}
          <div className="flex items-center gap-2 shrink-0">
            
            {/* PROMINENT "DOWNLOAD AS PDF" BUTTON */}
            <button
              onClick={() => setIsPdfModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs sm:text-sm font-bold bg-amber-800 hover:bg-amber-900 active:scale-98 text-white rounded-xl shadow-xs transition-all shrink-0 cursor-pointer"
              title="Preview, format, and download or print this chapter as a publication-ready PDF with archival citations"
            >
              <FileDown className="w-4 h-4 text-amber-200" />
              <span className="font-semibold">Download as PDF</span>
            </button>

            {/* Upload Draft File Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 active:scale-98 text-white rounded-xl transition-all shadow-2xs shrink-0 cursor-pointer"
              title="Upload existing draft (.docx, .html, .md, .txt) keeping all layout and formatting"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Upload Draft</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".docx,.doc,.html,.htm,.md,.markdown,.txt,.rtf"
              onChange={handleFileSelected}
              className="hidden"
            />

            {/* Insert Researched Fact Button */}
            <button
              onClick={() => setShowFactInserter(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-amber-100 hover:bg-amber-200 active:scale-98 text-amber-950 rounded-xl transition-all shadow-2xs shrink-0 border border-amber-300 cursor-pointer"
              title="Insert researched ancestry fact & citation into your manuscript"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">Insert Fact</span>
            </button>

            {/* Companion Tools */}
            {onOpenVoiceRecorder && (
              <button
                onClick={onOpenVoiceRecorder}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-stone-700 hover:bg-stone-200/80 transition-colors shrink-0"
                title="Grandpa's Voice Dictation & Oral Memories Recorder"
              >
                <Mic className="w-3.5 h-3.5 text-red-600" />
                <span className="hidden md:inline">Voice</span>
              </button>
            )}

            {onOpenMapModal && (
              <button
                onClick={onOpenMapModal}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-stone-700 hover:bg-stone-200/80 transition-colors shrink-0"
                title="Open Fitts Village & St. James Ancestral Land Map"
              >
                <Compass className="w-3.5 h-3.5 text-amber-700" />
                <span className="hidden md:inline">Land Map</span>
              </button>
            )}

            {/* Historical Google Search Grounding Button */}
            <button
              onClick={() => {
                if (selectedTerm) {
                  triggerSearchGrounding(selectedTerm);
                } else {
                  setIsGroundingOpen(!isGroundingOpen);
                }
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                isGroundingOpen
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200'
              }`}
              title="Highlight terms in text or click to open Google Search Grounding for historical context"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGroundingOpen ? 'text-amber-300' : 'text-blue-600'}`} />
              <span className="hidden sm:inline">Grounding</span>
            </button>

            {/* Archival Fact Chat Section Launcher */}
            {onOpenChatTab && (
              <button
                onClick={onOpenChatTab}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-stone-900 hover:bg-stone-800 active:scale-98 text-amber-200 rounded-xl transition-all shadow-2xs shrink-0 cursor-pointer"
                title="Open Archival Fact-Checking Chat & Google Search Grounding"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">Fact Chat</span>
              </button>
            )}

            {/* Quick Word export */}
            <button
              onClick={handleDownloadDoc}
              className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-200 rounded-lg transition-colors shrink-0"
              title="Download as Word Document (.doc)"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Direct Print */}
            <button
              onClick={handlePrint}
              className="p-1.5 text-stone-500 hover:text-stone-800 hover:bg-stone-200 rounded-lg transition-colors shrink-0"
              title="Quick Print Current Chapter"
            >
              <Printer className="w-4 h-4" />
            </button>

          </div>
        </div>

        {/* Tier 2: Formatting Ribbon with Segmented Controls */}
        <div className="px-3 py-1.5 flex items-center gap-1 text-stone-700 text-xs overflow-x-auto no-scrollbar whitespace-nowrap">
          
          {/* Undo / Redo */}
          <div className="flex items-center bg-stone-100/90 rounded-lg p-0.5 border border-stone-200/80">
            <button
              onClick={() => execCmd('undo')}
              className="p-1 hover:bg-white rounded transition-colors text-stone-700"
              title="Undo (Ctrl+Z)"
            >
              <Undo className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('redo')}
              className="p-1 hover:bg-white rounded transition-colors text-stone-700"
              title="Redo (Ctrl+Y)"
            >
              <Redo className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300/80 mx-1 shrink-0" />

          {/* Heading / Style Selector */}
          <select
            onChange={e => {
              const val = e.target.value;
              if (val === 'p') execCmd('formatBlock', '<p>');
              else if (val === 'h2') execCmd('formatBlock', '<h2>');
              else if (val === 'h3') execCmd('formatBlock', '<h3>');
              else if (val === 'h4') execCmd('formatBlock', '<h4>');
            }}
            className="bg-white border border-stone-300 rounded-lg px-2 py-1 text-xs text-stone-800 focus:outline-hidden"
            title="Paragraph Style"
          >
            <option value="p">Normal Text</option>
            <option value="h2">Section Title (H2)</option>
            <option value="h3">Subheading (H3)</option>
            <option value="h4">Minor Heading (H4)</option>
          </select>

          {/* Font Family Selector */}
          <select
            value={editorFontFamily}
            onChange={e => setEditorFontFamily(e.target.value as any)}
            className="bg-white border border-stone-300 rounded-lg px-2 py-1 text-xs text-stone-800 focus:outline-hidden"
            title="Book Font"
          >
            <option value="serif">Book Serif (Lora)</option>
            <option value="sans">Clean Modern (Sans)</option>
            <option value="mono">Typewriter (Monospace)</option>
          </select>

          {/* Font Size Adjusters */}
          <div className="flex items-center bg-white border border-stone-300 rounded-lg">
            <button
              onClick={() => setCustomFontSize(Math.max(12, customFontSize - 2))}
              className="p-1 hover:bg-stone-100 text-stone-600 rounded-l-lg"
              title="Decrease Font Size"
            >
              <Minus className="w-3 h-3" />
            </button>
            <span className="px-2 font-mono-data text-xs text-stone-800 font-medium">
              {scaleFontSize}pt
            </span>
            <button
              onClick={() => setCustomFontSize(Math.min(32, customFontSize + 2))}
              className="p-1 hover:bg-stone-100 text-stone-600 rounded-r-lg"
              title="Increase Font Size"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300/80 mx-1 shrink-0" />

          {/* Inline Text Formatting: Bold, Italic, Underline, Strikethrough */}
          <div className="flex items-center bg-stone-100/90 rounded-lg p-0.5 border border-stone-200/80">
            <button
              onClick={() => execCmd('bold')}
              className="p-1.5 hover:bg-white rounded font-bold transition-colors text-stone-800"
              title="Bold (Ctrl+B)"
            >
              <Bold className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('italic')}
              className="p-1.5 hover:bg-white rounded italic transition-colors text-stone-800"
              title="Italic (Ctrl+I)"
            >
              <Italic className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('underline')}
              className="p-1.5 hover:bg-white rounded underline transition-colors text-stone-800"
              title="Underline (Ctrl+U)"
            >
              <Underline className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('strikeThrough')}
              className="p-1.5 hover:bg-white rounded line-through transition-colors text-stone-800"
              title="Strikethrough"
            >
              <Strikethrough className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300/80 mx-1 shrink-0" />

          {/* Alignment */}
          <div className="flex items-center bg-stone-100/90 rounded-lg p-0.5 border border-stone-200/80">
            <button
              onClick={() => execCmd('justifyLeft')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Align Left"
            >
              <AlignLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('justifyCenter')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Align Center"
            >
              <AlignCenter className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('justifyRight')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Align Right"
            >
              <AlignRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('justifyFull')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Justify"
            >
              <AlignJustify className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300/80 mx-1 shrink-0" />

          {/* Lists & Quotes */}
          <div className="flex items-center bg-stone-100/90 rounded-lg p-0.5 border border-stone-200/80">
            <button
              onClick={() => execCmd('insertUnorderedList')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Bulleted List"
            >
              <List className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('insertOrderedList')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Numbered List"
            >
              <ListOrdered className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('formatBlock', '<blockquote>')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Insert Historical Blockquote"
            >
              <Quote className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => execCmd('insertHorizontalRule')}
              className="p-1.5 hover:bg-white rounded transition-colors text-stone-800"
              title="Insert Chapter Divider"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300/80 mx-1 shrink-0" />

          {/* Find & Search in Document */}
          <button
            onClick={() => {
              const nextOpen = !searchOpen;
              setSearchOpen(nextOpen);
              if (nextOpen) {
                setTimeout(() => searchInputRef.current?.focus(), 50);
              } else {
                clearHighlights();
              }
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              searchOpen
                ? 'bg-amber-800 text-white shadow-2xs'
                : 'hover:bg-stone-200 text-stone-700 bg-white border border-stone-300'
            }`}
            title="Find and replace text in manuscript (Ctrl+F)"
            aria-label="Find and replace text in manuscript"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Search</span>
            <kbd className="hidden sm:inline font-mono-data text-[10px] bg-black/10 px-1 rounded">Ctrl+F</kbd>
          </button>

        </div>
      </div>

      {/* GOOGLE DOCS STYLE FLOATING FIND & REPLACE BAR */}
      {searchOpen && (
        <div className="bg-white border-b border-amber-200 shadow-md px-4 py-2.5 z-20 flex flex-col gap-2 no-print">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-[280px]">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Find in manuscript..."
                  value={searchQuery}
                  onChange={e => {
                    const val = e.target.value;
                    setSearchQuery(val);
                    executeSearch(val, 0, matchCase);
                  }}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      if (e.shiftKey) handlePrevMatch();
                      else handleNextMatch();
                    } else if (e.key === 'Escape') {
                      setSearchOpen(false);
                      clearHighlights();
                    }
                  }}
                  className="w-full pl-8 pr-20 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:bg-white text-stone-900"
                />
                <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] font-mono-data text-stone-500">
                  {totalMatches > 0 ? `${currentMatchIndex + 1}/${totalMatches}` : searchQuery ? '0 found' : ''}
                </span>
              </div>

              {/* Prev / Next buttons */}
              <div className="flex items-center gap-1">
                <button
                  onClick={handlePrevMatch}
                  disabled={totalMatches === 0}
                  className="p-1.5 bg-stone-100 hover:bg-stone-200 disabled:opacity-40 rounded text-stone-700"
                  title="Previous match (Shift+Enter)"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleNextMatch}
                  disabled={totalMatches === 0}
                  className="p-1.5 bg-stone-100 hover:bg-stone-200 disabled:opacity-40 rounded text-stone-700"
                  title="Next match (Enter)"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Match Case Toggle */}
              <button
                onClick={() => {
                  const newCase = !matchCase;
                  setMatchCase(newCase);
                  executeSearch(searchQuery, 0, newCase);
                }}
                className={`px-2 py-1 rounded text-xs font-mono-data font-semibold border transition-colors ${
                  matchCase 
                    ? 'bg-amber-100 border-amber-400 text-amber-900' 
                    : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-stone-200'
                }`}
                title="Match Case (Aa)"
              >
                Aa
              </button>

              {/* Scope Selector: Current Chapter vs Whole Book */}
              <div className="flex items-center bg-stone-100 p-0.5 rounded-lg border border-stone-200 text-xs">
                <button
                  onClick={() => setSearchScope('chapter')}
                  className={`px-2 py-1 rounded transition-colors ${
                    searchScope === 'chapter' ? 'bg-white shadow-2xs font-semibold text-stone-900' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Current Chapter
                </button>
                <button
                  onClick={() => setSearchScope('all-chapters')}
                  className={`px-2 py-1 rounded transition-colors ${
                    searchScope === 'all-chapters' ? 'bg-white shadow-2xs font-semibold text-stone-900' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Entire Book
                </button>
              </div>

              {/* Toggle Replace Row */}
              <button
                onClick={() => setShowReplace(!showReplace)}
                className={`px-2.5 py-1 text-xs rounded border transition-colors ${
                  showReplace 
                    ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold' 
                    : 'bg-stone-100 border-stone-200 text-stone-700 hover:bg-stone-200'
                }`}
              >
                Replace...
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={() => {
                setSearchOpen(false);
                clearHighlights();
              }}
              className="p-1 text-stone-400 hover:text-stone-700 rounded"
              title="Close search (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Replace Row */}
          {showReplace && (
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-stone-100">
              <input
                type="text"
                placeholder="Replace with..."
                value={replaceQuery}
                onChange={e => setReplaceQuery(e.target.value)}
                className="w-72 px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:bg-white text-stone-900"
              />
              <button
                onClick={handleReplaceCurrent}
                disabled={totalMatches === 0}
                className="px-3 py-1.5 text-xs font-semibold bg-stone-800 hover:bg-stone-700 disabled:opacity-40 text-white rounded-lg transition-colors"
              >
                Replace
              </button>
              <button
                onClick={handleReplaceAll}
                disabled={totalMatches === 0}
                className="px-3 py-1.5 text-xs font-semibold bg-amber-700 hover:bg-amber-800 disabled:opacity-40 text-white rounded-lg transition-colors"
              >
                Replace All in Chapter
              </button>
            </div>
          )}

          {/* All Chapters Results Dropdown */}
          {searchScope === 'all-chapters' && searchQuery && (
            <div className="mt-2 p-3 bg-amber-50/60 rounded-lg border border-amber-200 max-h-48 overflow-y-auto space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-amber-900">
                <span>Matches Across Entire Book ({allChapterSearchResults.reduce((sum, r: any) => sum + r.matchCount, 0)} total):</span>
                <span className="text-[11px] font-normal text-amber-700">Click a chapter to open and highlight</span>
              </div>
              {allChapterSearchResults.length === 0 ? (
                <p className="text-xs text-stone-500 italic">No matches found in any chapter.</p>
              ) : (
                allChapterSearchResults.map((res: any) => (
                  <div
                    key={res.chapterId}
                    onClick={() => {
                      onSelectChapter(res.chapterId);
                      setSearchScope('chapter');
                    }}
                    className={`p-2 rounded border cursor-pointer text-xs transition-colors flex items-start justify-between gap-3 ${
                      res.chapterId === activeChapter.id
                        ? 'bg-amber-100/80 border-amber-300 font-medium'
                        : 'bg-white hover:bg-amber-100/40 border-stone-200'
                    }`}
                  >
                    <div>
                      <span className="font-semibold text-stone-900">{res.title}</span>
                      <p className="text-stone-600 text-[11px] font-serif-book mt-0.5">{res.snippet}</p>
                    </div>
                    <span className="px-2 py-0.5 bg-amber-200 text-amber-900 font-bold rounded text-[10px] shrink-0 font-mono-data">
                      {res.matchCount} {res.matchCount === 1 ? 'match' : 'matches'}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* MAIN WRITING VIEWPORT WITH CHAPTER SIDEBAR */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Chapter Outline Sidebar */}
        {sidebarOpen && (
          <>
            {/* Mobile backdrop */}
            <div
              onClick={() => setSidebarOpen(false)}
              className="md:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-xs"
            />
            <aside className="fixed md:static inset-y-0 left-0 z-50 w-72 bg-white border-r border-stone-200 flex flex-col shrink-0 no-print shadow-2xl md:shadow-none animate-in slide-in-from-left duration-200">
              <div className="p-3 border-b border-stone-200 flex items-center justify-between">
                <span className="font-bold text-xs uppercase tracking-wider text-stone-600">
                  Book Chapters ({chapters.length})
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={onAddChapter}
                    className="p-1 text-amber-700 hover:bg-amber-50 rounded flex items-center gap-1 text-xs font-semibold"
                    title="Add New Chapter"
                  >
                    <PlusCircle className="w-3.5 h-3.5" /> New Chapter
                  </button>
                  <button
                    onClick={() => setSidebarOpen(false)}
                    className="md:hidden p-1 text-stone-400 hover:text-stone-700 rounded"
                    title="Close outline"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {chapters.map((ch, idx) => {
                  const isActive = ch.id === activeChapter?.id;
                  return (
                    <div
                      key={ch.id}
                      onClick={() => {
                        onSelectChapter(ch.id);
                        if (window.innerWidth < 768) setSidebarOpen(false);
                      }}
                      className={`p-2.5 rounded-lg text-left cursor-pointer transition-all flex items-start justify-between gap-2 group ${
                        isActive 
                          ? 'bg-amber-50 border border-amber-300 text-stone-900 shadow-2xs' 
                          : 'hover:bg-stone-100 text-stone-700 border border-transparent'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] font-mono-data text-amber-800 font-bold">
                            {idx + 1}.
                          </span>
                          <h4 className="font-semibold text-xs truncate">
                            {ch.title}
                          </h4>
                        </div>
                        {ch.subtitle && (
                          <p className="text-[11px] text-stone-500 truncate mt-0.5">
                            {ch.subtitle}
                          </p>
                        )}
                        <span className="text-[10px] text-stone-400 font-mono-data mt-1 block">
                          {ch.wordCount.toLocaleString()} words
                        </span>
                      </div>

                      {chapters.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Delete "${ch.title}"?`)) {
                              onDeleteChapter(ch.id);
                            }
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-red-600 transition-opacity"
                          title="Delete Chapter"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Total Book Progress */}
              <div className="p-3 border-t border-stone-200 bg-stone-50 text-xs text-stone-600 space-y-1">
                <div className="flex justify-between">
                  <span>Total Words:</span>
                  <span className="font-mono-data font-bold text-stone-800">
                    {chapters.reduce((sum, c) => sum + c.wordCount, 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Reading Time:</span>
                  <span className="text-stone-700">
                    ~{Math.max(1, Math.round(chapters.reduce((sum, c) => sum + c.wordCount, 0) / 200))} mins
                  </span>
                </div>
              </div>
            </aside>
          </>
        )}

        {/* Center: Google Docs Paper Canvas with Realistic Paper Shadow & Margins */}
        <main 
          id="manuscript_scroll_container"
          className="flex-1 overflow-y-auto px-2 sm:px-6 py-3 sm:py-8 flex flex-col items-center"
        >
          {/* Centered White Document Page */}
          <div className="w-full max-w-[850px] bg-white rounded-xl sm:rounded-sm shadow-md border border-stone-300 min-h-[900px] p-4 sm:p-12 lg:p-16 space-y-5 sm:space-y-6 print-page">
            
            {/* Chapter Header */}
            <div className="border-b border-stone-200 pb-4">
              <input
                type="text"
                value={activeChapter?.title || ''}
                onChange={e => {
                  if (activeChapter) {
                    activeChapter.title = e.target.value;
                    handleInput();
                  }
                }}
                className="text-2xl sm:text-3xl font-bold font-serif-book text-stone-900 w-full focus:outline-hidden hover:bg-stone-50 px-1 rounded transition-colors"
                placeholder="Chapter Title..."
              />
              <input
                type="text"
                value={activeChapter?.subtitle || ''}
                onChange={e => {
                  if (activeChapter) {
                    activeChapter.subtitle = e.target.value;
                    handleInput();
                  }
                }}
                className="text-sm font-sans-ui text-stone-500 w-full focus:outline-hidden hover:bg-stone-50 px-1 rounded transition-colors mt-1"
                placeholder="Optional chapter subtitle or date range..."
              />
            </div>

            {/* If chapter content is empty, show welcoming blank slate with upload drop zone */}
            {(!activeChapter?.contentHtml || activeChapter.contentHtml.trim() === '') && (
              <div 
                onDragOver={(e) => { e.preventDefault(); setIsDraggingFile(true); }}
                onDragLeave={() => setIsDraggingFile(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDraggingFile(false);
                  const file = e.dataTransfer.files?.[0];
                  if (file) handleProcessFile(file);
                }}
                className={`p-6 sm:p-8 rounded-xl border-2 border-dashed transition-all flex flex-col items-center text-center no-print ${
                  isDraggingFile 
                    ? 'border-blue-500 bg-blue-50/80 scale-[1.01]' 
                    : 'border-stone-300 bg-stone-50/60 hover:bg-stone-50 hover:border-amber-400'
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center mb-3 shadow-xs">
                  <UploadCloud className="w-7 h-7 text-amber-700" />
                </div>

                <h3 className="text-lg font-bold text-stone-900 font-serif-book">
                  Start Typing or Upload Your Existing Manuscript
                </h3>
                <p className="text-xs sm:text-sm text-stone-600 max-w-lg mt-1 mb-4 leading-normal">
                  Grandpa Ward can start writing on this clean page, or click below to upload an existing draft file.
                  KinScribe will preserve your headings, paragraphs, bold/italics, and chapter formatting!
                </p>

                {uploadError && (
                  <div className="mb-3 px-3 py-1.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs font-medium">
                    {uploadError}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center gap-2 shadow-xs transition-colors"
                  >
                    <FileUp className="w-4 h-4" />
                    <span>{isUploading ? 'Importing & Preserving Formatting...' : 'Upload Existing File (.docx, .html, .md, .txt)'}</span>
                  </button>

                  <button
                    onClick={() => {
                      if (editorRef.current) {
                        editorRef.current.focus();
                      }
                    }}
                    className="px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-200/70 rounded-xl transition-colors border border-stone-300"
                  >
                    Or Start Typing Below ↓
                  </button>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-200/80 flex flex-wrap items-center justify-center gap-3 text-[11px] text-stone-500">
                  <span className="flex items-center gap-1 font-medium text-stone-700">
                    <FileType className="w-3.5 h-3.5 text-blue-600" /> Word (.docx)
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1 font-medium text-stone-700">
                    <FileCode className="w-3.5 h-3.5 text-amber-700" /> HTML (.html)
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1 font-medium text-stone-700">
                    <FileText className="w-3.5 h-3.5 text-emerald-700" /> Markdown (.md)
                  </span>
                  <span>·</span>
                  <span className="flex items-center gap-1 font-medium text-stone-700">
                    <FileText className="w-3.5 h-3.5 text-stone-600" /> Plain Text (.txt)
                  </span>
                </div>
              </div>
            )}

            {/* Editable Content Area */}
            <div
              ref={editorRef}
              contentEditable
              onInput={handleInput}
              onMouseUp={(e) => {
                handleMouseUp();
                handleEditorSelection();
              }}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              onTouchCancel={handleTouchEnd}
              onKeyUp={handleEditorSelection}
              style={{ fontSize: `${scaleFontSize}px` }}
              className={`min-h-[450px] focus:outline-hidden text-stone-900 leading-relaxed space-y-4 ${fontClass} selection:bg-amber-100 empty:before:content-[attr(data-placeholder)] empty:before:text-stone-400 select-text`}
              data-placeholder="Click here to begin writing your manuscript chapter..."
            />

            {/* Footnotes & Archival Citations Section */}
            <div className="pt-8 mt-12 border-t-2 border-stone-200 text-xs text-stone-600 space-y-3 font-sans-ui archival-citations-block">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-1 border-b border-stone-100">
                <div className="flex items-center gap-2">
                  <BookMarked className="w-4 h-4 text-amber-800" />
                  <h3 className="font-bold uppercase tracking-wider text-stone-800">
                    Archival Citations & Verified Sources ({citations.length})
                  </h3>
                </div>
                <button
                  onClick={() => setIsPdfModalOpen(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 rounded-lg transition-colors cursor-pointer no-print shadow-2xs"
                  title="Generate printable PDF of this chapter with citations"
                >
                  <FileDown className="w-3.5 h-3.5 text-amber-700" />
                  <span>Download as PDF</span>
                </button>
              </div>

              {citations.length === 0 ? (
                <p className="text-stone-400 italic">
                  No citations added yet. Click <em>"Cite in Book"</em> on any fact in the Research tab or use the <em>"Insert Researched Fact"</em> button above to automatically link proof records!
                </p>
              ) : (
                <ol className="space-y-2 list-decimal list-inside text-stone-700">
                  {citations.map((cite, idx) => (
                    <li key={cite.id} className="leading-normal hover:bg-stone-50 p-1 rounded">
                      <span className="font-semibold text-stone-900">
                        [{cite.number || idx + 1}] {cite.eventTitle} ({cite.ancestorName}):
                      </span>{' '}
                      <span className="text-stone-700 font-serif-book">{cite.fullCitation}</span>{' '}
                      <a
                        href={cite.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-0.5 text-blue-700 hover:underline font-medium ml-1"
                      >
                        Verify on {cite.provider === 'familysearch' ? 'FamilySearch' : 'Ancestry'} <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </li>
                  ))}
                </ol>
              )}
            </div>

          </div>

          {/* Footer stats below page */}
          <div className="mt-4 text-xs text-stone-500 font-mono-data no-print">
            Page 1 · {wordCount} words in this chapter · Auto-saved to browser storage
          </div>
        </main>

        {/* Right: Google Search Grounding Sidebar */}
        <GroundingSidebar
          isOpen={isGroundingOpen}
          onClose={() => setIsGroundingOpen(false)}
          selectedTerm={selectedTerm}
          isLoading={groundingLoading}
          result={groundingResult}
          error={groundingError}
          onInsertExplanationToDraft={handleInsertGroundingToDraft}
          onSearchNewTerm={(term) => triggerSearchGrounding(term)}
          recentSearches={recentSearches}
        />

        {/* Dictionary & Historical Terminology Look Up Popover */}
        <LookUpPopover
          word={lookupWord}
          context={lookupContext}
          targetRect={lookupRect}
          isOpen={isLookupOpen}
          onClose={() => setIsLookupOpen(false)}
          onCiteInDraft={handleInsertLookupToDraft}
          onDeepSearchContext={(term) => triggerSearchGrounding(term)}
        />

        {/* Floating Action Bubble on Highlighted Text */}
        {floatingGroundingBtn && (
          <div
            style={{
              position: 'fixed',
              left: `${floatingGroundingBtn.x}px`,
              top: `${floatingGroundingBtn.y}px`,
              transform: 'translate(-50%, -100%)',
              zIndex: 60
            }}
            className="flex items-center gap-1.5 p-1 bg-stone-900/95 text-white rounded-full shadow-2xl ring-2 ring-white/90 animate-in fade-in zoom-in-95 duration-150 no-print backdrop-blur-xs"
          >
            {/* Quick Look Up button for words/short terms */}
            {selectedTerm.split(/\s+/).length <= 3 && (
              <button
                onMouseDown={(e) => {
                  e.preventDefault();
                  const selection = window.getSelection();
                  let rect: DOMRect | null = null;
                  if (selection && selection.rangeCount > 0) {
                    rect = selection.getRangeAt(0).getBoundingClientRect();
                  }
                  triggerWordLookup(
                    selectedTerm, 
                    rect || new DOMRect(floatingGroundingBtn.x, floatingGroundingBtn.y, 0, 0), 
                    selectionContext
                  );
                }}
                className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 active:scale-95 text-stone-950 rounded-full font-sans-ui text-xs font-bold transition-all cursor-pointer shadow-sm"
                title="Look up dictionary definition and archival terminology explanation"
              >
                <BookOpen className="w-3.5 h-3.5 text-stone-950" />
                <span>Look Up</span>
              </button>
            )}

            {/* Google Search Grounding button */}
            <button
              onMouseDown={(e) => {
                e.preventDefault();
                triggerSearchGrounding(selectedTerm);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-full font-sans-ui text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Lookup historical background for highlighted phrase with Google Search Grounding"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>Ground "{selectedTerm.slice(0, 14)}{selectedTerm.length > 14 ? '...' : ''}"</span>
              <Search className="w-3 h-3 ml-0.5 text-blue-200" />
            </button>
          </div>
        )}

      </div>

      {/* QUICK FACT INSERTER MODAL */}
      {showFactInserter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white max-w-xl w-full rounded-xl shadow-2xl border border-stone-300 p-6 text-stone-900 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-700" />
                <h3 className="font-bold text-stone-900 text-base">
                  Insert Researched Fact into Manuscript
                </h3>
              </div>
              <button onClick={() => setShowFactInserter(false)} className="text-stone-400 hover:text-stone-700">
                ✕
              </button>
            </div>

            <p className="text-xs text-stone-600">
              Select any verified record from your research. KinScribe will insert the historical sentence right into your chapter and create a footnote citation with a live link back to FamilySearch or Ancestry:
            </p>

            <div className="max-h-80 overflow-y-auto space-y-2 pr-1">
              {allFacts.slice(0, 8).map(fact => {
                const anc = ancestors.find(a => a.id === fact.ancestorId);
                const src = fact.sources[0];

                return (
                  <div
                    key={fact.id}
                    className="p-3 bg-stone-50 hover:bg-amber-50/60 rounded-lg border border-stone-200 hover:border-amber-300 transition-colors flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-amber-900 font-mono-data">
                          {fact.year}
                        </span>
                        <span className="font-semibold text-stone-800">
                          {fact.title}
                        </span>
                        <span className="text-[10px] text-stone-500 bg-white px-1.5 py-0.2 rounded border">
                          {anc?.name}
                        </span>
                      </div>
                      <p className="text-stone-600 line-clamp-2">
                        {fact.description}
                      </p>
                      <div className="text-[11px] text-stone-500">
                        Source: {src.sourceTitle} ({src.provider === 'familysearch' ? 'FamilySearch' : 'Ancestry'})
                      </div>
                    </div>

                    <button
                      onClick={() => handleInsertFact(fact, src)}
                      className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-amber-200 font-semibold rounded-md shrink-0 shadow-2xs"
                    >
                      Insert & Cite
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowFactInserter(false)}
                className="px-4 py-2 text-xs text-stone-600 hover:bg-stone-100 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CHAPTER PDF EXPORT & PUBLICATION PREVIEW MODAL */}
      <ChapterPdfExportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        chapter={activeChapter}
        documentTitle={documentTitle}
        citations={citations}
      />

    </div>
  );
};
