import React from 'react';
import { Search, ExternalLink, Sparkles, X, Loader2, BookOpen, Quote, History } from 'lucide-react';
import { HistoricalSearchQuery } from '../types/genealogy';

export interface GroundingResult {
  term: string;
  explanation: string;
  sources: { title: string; uri: string }[];
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  selectedTerm: string;
  isLoading: boolean;
  result: GroundingResult | null;
  error: string | null;
  onInsertExplanationToDraft?: (text: string) => void;
  onSearchNewTerm?: (term: string) => void;
  recentSearches?: HistoricalSearchQuery[];
}

export const GroundingSidebar: React.FC<Props> = ({
  isOpen,
  onClose,
  selectedTerm,
  isLoading,
  result,
  error,
  onInsertExplanationToDraft,
  onSearchNewTerm,
  recentSearches = []
}) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Mobile backdrop */}
      <div
        onClick={onClose}
        className="md:hidden fixed inset-0 z-40 bg-black/50 backdrop-blur-xs"
      />
      <aside className="fixed md:static inset-y-0 right-0 z-50 w-full sm:w-96 bg-white border-l border-stone-200 shadow-2xl flex flex-col h-full shrink-0 transition-all animate-in slide-in-from-right duration-200 no-print">
        {/* Top Header */}
      <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50/50 border-b border-blue-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Search className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-bold text-stone-900 text-sm">
                Google Search Grounding
              </h3>
              <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded-full border border-blue-200">
                Live Web
              </span>
            </div>
            <p className="text-[11px] text-stone-500">
              Historical context & archival verification for manuscript writing
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 transition-colors"
          title="Close Research Grounding Sidebar"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Query Search Bar */}
      <div className="p-3 border-b border-stone-200 bg-stone-50">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const input = (e.currentTarget.elements.namedItem('search_input') as HTMLInputElement)?.value;
            if (input && onSearchNewTerm) {
              onSearchNewTerm(input.trim());
            }
          }}
          className="relative"
        >
          <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            name="search_input"
            type="text"
            defaultValue={selectedTerm}
            placeholder="Search historical term..."
            className="w-full pl-8 pr-16 py-1.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-stone-900"
          />
          <button
            type="submit"
            className="absolute right-1 top-1/2 -translate-y-1/2 px-2 py-0.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold"
          >
            Lookup
          </button>
        </form>

        {recentSearches && recentSearches.length > 0 && (
          <div className="pt-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[10px] text-stone-500 font-semibold shrink-0 flex items-center gap-0.5">
              <History className="w-2.5 h-2.5 text-blue-600" /> Recent:
            </span>
            {recentSearches.slice(0, 4).map(q => (
              <button
                key={q.id}
                type="button"
                onClick={() => onSearchNewTerm?.(q.term)}
                className="text-[10px] px-2 py-0.5 rounded-full bg-white hover:bg-blue-50 border border-stone-200 hover:border-blue-300 text-stone-700 hover:text-blue-800 shrink-0 font-medium transition-colors truncate max-w-[140px]"
                title={`Re-run search for "${q.term}"`}
              >
                {q.term}
              </button>
            ))}
          </div>
        )}

        <span className="text-[10px] text-stone-500 block mt-1">
          Highlight any phrase in your chapter to lookup context automatically.
        </span>
      </div>

      {/* Body Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading && (
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
            <div className="space-y-0.5">
              <h4 className="font-semibold text-stone-800 text-xs">Grounding with Google Search...</h4>
              <p className="text-[11px] text-stone-500">Querying historical databases for "{selectedTerm}"</p>
            </div>
          </div>
        )}

        {error && !isLoading && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs space-y-1">
            <span className="font-bold">Lookup Error:</span>
            <p>{error}</p>
          </div>
        )}

        {result && !isLoading && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Highlighted Term Card */}
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-1">
              <span className="text-[10px] uppercase font-bold text-blue-800 tracking-wider">
                Highlighted Term
              </span>
              <h4 className="font-bold text-stone-900 text-base font-serif-book">
                "{result.term}"
              </h4>
            </div>

            {/* Grounded Explanation */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-stone-800 uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Historical Context & Background:</span>
              </div>
              <div className="p-3.5 bg-white rounded-xl border border-stone-200 text-xs sm:text-sm text-stone-700 leading-relaxed font-sans-ui shadow-2xs whitespace-pre-line">
                {result.explanation}
              </div>
            </div>

            {/* Insert to Chapter Action */}
            {onInsertExplanationToDraft && (
              <button
                onClick={() => onInsertExplanationToDraft(result.explanation)}
                className="w-full py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                title="Insert this grounded context snippet into active manuscript chapter"
              >
                <Quote className="w-3.5 h-3.5 text-amber-300" />
                <span>Insert Context into Chapter</span>
              </button>
            )}

            {/* Grounding Web Citations & Sources */}
            {result.sources && result.sources.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-stone-200">
                <span className="text-[11px] font-bold text-stone-700 uppercase tracking-wider block">
                  Grounding Sources & Verified Links ({result.sources.length})
                </span>
                <div className="space-y-1.5">
                  {result.sources.map((src, sIdx) => (
                    <a
                      key={sIdx}
                      href={src.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-stone-50 hover:bg-blue-50/70 border border-stone-200 hover:border-blue-300 transition-colors flex items-center justify-between text-xs text-stone-800 group"
                    >
                      <div className="min-w-0 pr-2">
                        <span className="font-semibold block truncate group-hover:text-blue-700">
                          {src.title || 'Historical Document'}
                        </span>
                        <span className="text-[10px] text-stone-400 font-mono-data truncate block">
                          {src.uri}
                        </span>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-stone-400 group-hover:text-blue-600 shrink-0" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

        {/* Footer Helper */}
        <div className="p-3 bg-stone-50 border-t border-stone-200 text-[11px] text-stone-500">
          Google Search grounding provides real-time historical facts from colonial gazettes, archives, and Caribbean histories.
        </div>
      </aside>
    </>
  );
};
