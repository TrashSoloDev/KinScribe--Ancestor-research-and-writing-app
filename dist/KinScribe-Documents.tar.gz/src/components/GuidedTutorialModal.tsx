import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Lightbulb, 
  UploadCloud, 
  Star, 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Sparkles, 
  Check, 
  FileText,
  Compass,
  Mic,
  ArrowRight
} from 'lucide-react';

export interface TutorialStep {
  title: string;
  subtitle: string;
  tabTarget?: 'writer' | 'research' | 'chat';
  badge: string;
  description: string;
  details: string[];
  proTip: string;
  icon: React.ReactNode;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSwitchTab?: (tab: 'writer' | 'research' | 'chat') => void;
  activeTab?: 'writer' | 'research' | 'chat';
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    title: 'Welcome, Grandpa Ward!',
    subtitle: 'Your Personal Studio for the Follow-up to "The Fitts Village Story"',
    badge: 'Introduction',
    icon: <Sparkles className="w-6 h-6 text-amber-500" />,
    description: 'KinScribe is tailored specifically for writing your next genealogy book. It connects directly with verified Barbados parish records, FamilySearch archives, and Ancestry.com while providing a distraction-free manuscript canvas.',
    details: [
      'Two primary modes: "My Manuscript Book" for writing and "Genealogy Research" for archival facts.',
      'Auto-saved scroll memory: when you switch back and forth, the app always remembers your exact reading and typing position.',
      'Senior-friendly large print toggle and one-click Amazon KDP 6"×9" paperback export.'
    ],
    proTip: 'Everything is auto-saved right to your device in real-time. You never have to worry about losing your work.',
  },
  {
    title: 'The Clean Writing Canvas & Draft Uploader',
    subtitle: 'Start with a Fresh Page or Import an Existing Manuscript',
    tabTarget: 'writer',
    badge: 'Writing Tab',
    icon: <UploadCloud className="w-6 h-6 text-blue-500" />,
    description: 'Your writing tab starts blank so you have a clean slate. You can begin typing immediately or upload an existing file from your computer.',
    details: [
      'Uploads Microsoft Word (.docx), HTML, Markdown, or plain text (.txt).',
      'Keeps the exact same formatting: headings, chapter titles, bold/italics, and indented paragraphs are preserved 100%.',
      'Detects chapters automatically and adds them to your left-hand Chapter Outline.'
    ],
    proTip: 'Use "Search" or press Ctrl+F anytime to find or replace names and places across your entire manuscript.',
  },
  {
    title: 'Genealogy Research & Deduplication',
    subtitle: 'FamilySearch & Ancestry.com Dual Records Compiled',
    tabTarget: 'research',
    badge: 'Research Tab',
    icon: <Search className="w-6 h-6 text-emerald-600" />,
    description: 'The research timeline compiles parish church records, colonial censuses, and boatbuilding registries from FamilySearch and Ancestry for Ward Scott, Ancil, Joseph, and Samuel.',
    details: [
      'Deduplication engine: Identical events recorded on both sites are merged with dual-source badges.',
      'Parish Filters: Filter by St. James (Fitts Village & Holetown), St. Michael (Black Rock Archives), St. Thomas, or UK Diaspora.',
      'Decade selector: Jump straight to the 1850s, 1910s, or 1950s with one tap.'
    ],
    proTip: 'Click "Verify on FS" or "Verify on Ancestry" on any card to view the original digitized register scan.',
  },
  {
    title: 'Automated Thematic Insights Sidebar',
    subtitle: 'Recurring Themes & Chapter Inspiration for Your Book',
    tabTarget: 'research',
    badge: 'New Feature',
    icon: <Lightbulb className="w-6 h-6 text-amber-500" />,
    description: 'The automated Thematic Insight sidebar scans the timeline to discover recurring family patterns, crafts, and locations across generations.',
    details: [
      'Identifies themes like "Boatbuilding & Maritime Trades", "St. James Parish Church & Holetown Sacraments", and "Freehold Land Conveyance".',
      'Gives you instant chapter title ideas and narrative prompts for your book.',
      'Click "Filter Timeline" to isolate all events matching a theme, or "Draft as Book Chapter" to start writing immediately.'
    ],
    proTip: 'Clicking "Draft as Book Chapter" creates a new numbered chapter with the historical theme pre-filled in your manuscript!',
  },
  {
    title: 'Flag Key Discoveries with the Star Button',
    subtitle: 'Pin Milestone Facts for Priority Book Citations',
    tabTarget: 'research',
    badge: 'Research Tab',
    icon: <Star className="w-6 h-6 text-amber-500 fill-amber-400" />,
    description: 'As you uncover vital proofs, flag them so you do not lose track of the most important stories for your chapters.',
    details: [
      'Click the "Star" button on any fact card to mark it as a Key Discovery.',
      'Toggle the "Starred Only" filter button at the top to focus exclusively on your starred milestone records.',
      'Click "Cite in Book" on any fact to insert an archival footnote into your active chapter.'
    ],
    proTip: 'Footnotes automatically link to the online archive URL so your book readers can verify your historical proofs.',
  },
  {
    title: 'Companion Tools: Land Map & Voice Memories',
    subtitle: 'Oral Histories and West Coast Geography',
    badge: 'Companion Tools',
    icon: <Compass className="w-6 h-6 text-amber-700" />,
    description: 'Grandpa Ward has full companion tools designed to capture the living oral traditions of Fitts Village.',
    details: [
      'Voice Memories: Speak directly into your microphone; KinScribe transcribes your spoken words into chapter paragraphs.',
      'Land & Kinship Map: Interactive map of Highway 1, Fitts Village Beach, St. James Parish Church, and historical boat-launching wharves.',
      'Historical Scrapbook: Browse photos of cedar sloops, parish deeds, and archival photographs to attach to chapters.'
    ],
    proTip: 'Tap the red microphone button "Voice Memories" in the top bar to record spoken thoughts whenever you want to rest your typing hands!',
  }
];

export const GuidedTutorialModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSwitchTab,
  activeTab
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isOpen) return null;

  const step = TUTORIAL_STEPS[currentStepIndex];
  const isFirst = currentStepIndex === 0;
  const isLast = currentStepIndex === TUTORIAL_STEPS.length - 1;

  const handleNext = () => {
    if (!isLast) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      const nextStep = TUTORIAL_STEPS[nextIdx];
      if (nextStep.tabTarget && onSwitchTab) {
        onSwitchTab(nextStep.tabTarget);
      }
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (!isFirst) {
      const prevIdx = currentStepIndex - 1;
      setCurrentStepIndex(prevIdx);
      const prevStep = TUTORIAL_STEPS[prevIdx];
      if (prevStep.tabTarget && onSwitchTab) {
        onSwitchTab(prevStep.tabTarget);
      }
    }
  };

  const jumpToStep = (index: number) => {
    setCurrentStepIndex(index);
    const target = TUTORIAL_STEPS[index];
    if (target.tabTarget && onSwitchTab) {
      onSwitchTab(target.tabTarget);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white max-w-2xl w-full rounded-2xl shadow-2xl border border-stone-300 flex flex-col overflow-hidden text-stone-900 max-h-[92vh]">
        
        {/* Top Header & Step Tracker */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-50 via-stone-50 to-amber-100/50 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-600 text-white rounded-xl shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900">
                Grandpa Ward's Guided Tour
              </span>
              <h2 className="text-sm font-semibold text-stone-700">
                Step {currentStepIndex + 1} of {TUTORIAL_STEPS.length}: {step.badge}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 rounded-lg transition-colors"
            title="Close Tutorial"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Dots */}
        <div className="flex items-center gap-1.5 px-6 pt-3 bg-stone-50/50">
          {TUTORIAL_STEPS.map((s, idx) => (
            <button
              key={idx}
              onClick={() => jumpToStep(idx)}
              className={`h-2 rounded-full transition-all flex-1 ${
                idx === currentStepIndex
                  ? 'bg-amber-700 shadow-xs ring-1 ring-amber-600'
                  : idx < currentStepIndex
                    ? 'bg-emerald-500'
                    : 'bg-stone-200 hover:bg-stone-300'
              }`}
              title={`Jump to: ${s.title}`}
            />
          ))}
        </div>

        {/* Main Content Area */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-2xl bg-amber-100/80 border border-amber-200 shadow-xs shrink-0">
              {step.icon}
            </div>

            <div className="space-y-1">
              <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                {step.badge}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-serif-book text-stone-900 leading-tight">
                {step.title}
              </h3>
              <p className="text-xs sm:text-sm font-medium text-stone-500">
                {step.subtitle}
              </p>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm text-stone-700 leading-relaxed">
            {step.description}
          </p>

          {/* Bullet Highlights */}
          <div className="p-4 rounded-xl bg-stone-50 border border-stone-200/80 space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700">
              Key Capabilities:
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-stone-700">
              {step.details.map((item, dIdx) => (
                <li key={dIdx} className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Pro Tip Box */}
          <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-amber-950 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong>Tip for Ward:</strong> {step.proTip}
            </div>
          </div>

          {/* If step targets a specific tab, show quick switch hint */}
          {step.tabTarget && onSwitchTab && activeTab !== step.tabTarget && (
            <div className="flex items-center justify-between p-2.5 bg-blue-50/70 border border-blue-200 rounded-lg text-xs text-blue-900">
              <span>This feature is located on the <strong>{step.tabTarget === 'writer' ? 'My Manuscript Book' : 'Genealogy Research'}</strong> tab.</span>
              <button
                onClick={() => onSwitchTab(step.tabTarget!)}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md shadow-2xs shrink-0 flex items-center gap-1"
              >
                <span>Switch Tab</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}

        </div>

        {/* Footer Navigation Buttons */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            onClick={handlePrev}
            disabled={isFirst}
            className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold border border-stone-300 text-stone-700 hover:bg-stone-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <div className="text-xs text-stone-500 font-mono-data">
            {currentStepIndex + 1} / {TUTORIAL_STEPS.length}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-2 text-xs font-semibold text-stone-500 hover:text-stone-800"
            >
              Skip Tour
            </button>
            <button
              onClick={handleNext}
              className="px-5 py-2 rounded-xl text-xs sm:text-sm font-bold bg-amber-900 hover:bg-amber-950 text-white flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <span>{isLast ? "Done, Let's Write!" : 'Next Step'}</span>
              {!isLast && <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
