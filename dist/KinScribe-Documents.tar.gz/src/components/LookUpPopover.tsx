import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Copy, 
  Check, 
  X, 
  ScrollText, 
  ExternalLink,
  Volume2,
  FilePlus,
  Compass
} from 'lucide-react';

export interface DictionaryLookupData {
  word: string;
  partOfSpeech: string;
  phonetic?: string;
  definition: string;
  historicalExplanation: string;
  recordsRelevance: string[];
}

interface LookUpPopoverProps {
  word: string;
  context?: string;
  targetRect: DOMRect | null;
  isOpen: boolean;
  onClose: () => void;
  onCiteInDraft: (insertedHtml: string) => void;
  onDeepSearchContext: (term: string) => void;
}

export const LookUpPopover: React.FC<LookUpPopoverProps> = ({
  word,
  context,
  targetRect,
  isOpen,
  onClose,
  onCiteInDraft,
  onDeepSearchContext
}) => {
  const [data, setData] = useState<DictionaryLookupData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [popoverPos, setPopoverPos] = useState<{ top: number; left: number; arrowSide: 'top' | 'bottom' }>({
    top: 100,
    left: 20,
    arrowSide: 'top'
  });

  const popoverRef = useRef<HTMLDivElement>(null);

  // Fetch dictionary & historical terminology lookup
  useEffect(() => {
    if (!isOpen || !word) return;

    let isMounted = true;
    setLoading(true);
    setError(null);
    setData(null);

    const fetchLookup = async () => {
      try {
        const resp = await fetch('/api/dictionary/lookup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ word, context })
        });

        if (!resp.ok) {
          throw new Error(`Failed to lookup "${word}"`);
        }

        const result: DictionaryLookupData = await resp.json();
        if (isMounted) {
          setData(result);
        }
      } catch (err: any) {
        if (isMounted) {
          setError(err?.message || 'Could not load terminology definition');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchLookup();

    return () => {
      isMounted = false;
    };
  }, [word, context, isOpen]);

  // Compute popover position anchored to targetRect
  useEffect(() => {
    if (!targetRect || !isOpen) return;

    const popoverWidth = Math.min(360, window.innerWidth - 32);
    const popoverEstimatedHeight = 380;
    const padding = 16;

    // Center horizontally on target, clamped within viewport bounds
    let left = targetRect.left + targetRect.width / 2 - popoverWidth / 2;
    if (left < padding) left = padding;
    if (left + popoverWidth > window.innerWidth - padding) {
      left = window.innerWidth - padding - popoverWidth;
    }

    // Determine whether to place above or below word
    const spaceBelow = window.innerHeight - targetRect.bottom;
    const spaceAbove = targetRect.top;

    let top = 0;
    let arrowSide: 'top' | 'bottom' = 'top';

    if (spaceBelow >= popoverEstimatedHeight || spaceBelow > spaceAbove) {
      // Place below word
      top = Math.min(targetRect.bottom + 8, window.innerHeight - 200);
      arrowSide = 'top';
    } else {
      // Place above word
      top = Math.max(12, targetRect.top - popoverEstimatedHeight - 8);
      arrowSide = 'bottom';
    }

    setPopoverPos({ top, left, arrowSide });
  }, [targetRect, isOpen, data]);

  // Handle outside clicks to dismiss
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('touchstart', handlePointerDown);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleCopy = () => {
    if (!data) return;
    const textToCopy = `${data.word.toUpperCase()} (${data.partOfSpeech}${data.phonetic ? ` ${data.phonetic}` : ''}):\n${data.definition}\n\nHistorical Context:\n${data.historicalExplanation}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInsertCite = () => {
    if (!data) return;
    const snippetHtml = `
      <aside class="glossary-term-note p-3 my-3 bg-stone-50 border-l-4 border-amber-800 rounded-r-lg font-serif text-stone-800 text-sm leading-relaxed shadow-xs">
        <div class="font-bold text-amber-900 tracking-wide mb-1 uppercase text-xs flex items-center gap-1.5">
          <span>Terminology Note: ${data.word}</span>
          ${data.partOfSpeech ? `<span class="normal-case italic text-stone-500 font-normal">(${data.partOfSpeech})</span>` : ''}
        </div>
        <p class="mb-1.5">${data.definition}</p>
        <p class="text-xs text-stone-600 italic bg-amber-50/50 p-2 rounded">
          <strong>Archival Significance:</strong> ${data.historicalExplanation}
        </p>
      </aside>
      <p><br/></p>
    `;
    onCiteInDraft(snippetHtml);
    onClose();
  };

  return (
    <>
      {/* Dim backdrop on small screens for touch focus */}
      <div 
        className="fixed inset-0 bg-black/25 z-60 sm:hidden transition-opacity" 
        onClick={onClose}
      />

      <div
        ref={popoverRef}
        role="dialog"
        aria-label={`Definition for ${word}`}
        style={{
          position: 'fixed',
          top: `${popoverPos.top}px`,
          left: `${popoverPos.left}px`,
          maxWidth: '360px',
          width: 'calc(100vw - 32px)',
          zIndex: 70
        }}
        className="bg-[#1e1b18] text-[#f7f4ef] rounded-2xl shadow-2xl border border-stone-700/80 overflow-hidden font-sans-ui animate-in fade-in zoom-in-95 duration-150 no-print"
      >
        {/* Header Bar */}
        <div className="flex items-start justify-between p-3.5 pb-2.5 border-b border-stone-800 bg-[#282420]">
          <div className="flex items-start gap-2.5 min-w-0 pr-2">
            <div className="p-1.5 bg-amber-950/70 border border-amber-700/40 rounded-xl text-amber-400 shrink-0 mt-0.5">
              <BookOpen className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-baseline gap-2 flex-wrap">
                <h3 className="font-serif font-bold text-lg text-amber-200 tracking-tight capitalize truncate">
                  {data?.word || word}
                </h3>
                {data?.phonetic && (
                  <span className="text-xs text-stone-400 font-mono tracking-wider">
                    {data.phonetic}
                  </span>
                )}
                {data?.partOfSpeech && (
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-amber-400/90 bg-amber-900/30 px-1.5 py-0.5 rounded">
                    {data.partOfSpeech}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-stone-400 truncate">
                Manuscript Glossary & Archival Terminology
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-11 h-11 -mr-2 -mt-2 flex items-center justify-center text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-full transition-colors active:scale-95"
            aria-label="Close look up popover"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-3.5 space-y-3 max-h-[60vh] overflow-y-auto overscroll-contain">
          {loading && (
            <div className="py-8 flex flex-col items-center justify-center gap-2.5 text-stone-400">
              <div className="w-6 h-6 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs font-medium">Looking up terminology...</span>
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-950/40 border border-red-800/50 rounded-xl text-red-200 text-xs">
              <p className="font-semibold mb-1">Lookup Unavailable</p>
              <p>{error}</p>
            </div>
          )}

          {data && !loading && (
            <>
              {/* Primary Definition */}
              <div className="space-y-1">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Standard Definition
                </h4>
                <p className="text-sm font-serif-book leading-relaxed text-stone-100">
                  {data.definition}
                </p>
              </div>

              {/* Historical Terminology Explanation */}
              {data.historicalExplanation && (
                <div className="p-3 bg-[#2a241e] border-l-3 border-amber-500 rounded-r-xl space-y-1.5">
                  <div className="flex items-center gap-1.5 text-amber-300 text-xs font-semibold">
                    <ScrollText className="w-3.5 h-3.5 text-amber-400" />
                    <span>Barbadian & Historical Context</span>
                  </div>
                  <p className="text-xs font-serif-book text-stone-300 leading-relaxed">
                    {data.historicalExplanation}
                  </p>
                </div>
              )}

              {/* Relevant Records Section */}
              {data.recordsRelevance && data.recordsRelevance.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                    Appears In Archival Records:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {data.recordsRelevance.map((rec, i) => (
                      <span
                        key={i}
                        className="text-[11px] bg-stone-800/90 text-stone-300 border border-stone-700/60 px-2 py-0.5 rounded-md"
                      >
                        {rec}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        {data && !loading && (
          <div className="p-2.5 bg-[#25211d] border-t border-stone-800/80 flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-stone-300 hover:text-stone-100 hover:bg-stone-800 active:scale-95 rounded-lg transition-colors border border-stone-700/50"
                title="Copy definition to clipboard"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-stone-400" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onDeepSearchContext(data.word);
                  onClose();
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-amber-300 hover:text-amber-100 hover:bg-amber-950/60 active:scale-95 rounded-lg transition-colors border border-amber-800/50"
                title="Open live Google Search Grounding for this term"
              >
                <Compass className="w-3.5 h-3.5 text-amber-400" />
                <span>Deep Grounding</span>
              </button>
            </div>

            <button
              onClick={handleInsertCite}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 active:scale-95 text-stone-950 font-semibold text-xs rounded-lg transition-all shadow-md ml-auto"
              title="Insert historical terminology note into manuscript draft"
            >
              <FilePlus className="w-3.5 h-3.5 text-stone-900" />
              <span>Cite in Draft</span>
            </button>
          </div>
        )}
      </div>
    </>
  );
};
